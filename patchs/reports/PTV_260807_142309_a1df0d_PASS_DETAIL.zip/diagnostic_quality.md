# Diagnostic quality

- tool_version: `5.16.0`
- structured_diagnostic_count: `2`
- root_cause_count: `2`
- secondary_suppressed: `0`
- raw_lines: `148`
- important_lines: `142`
- reduction_ratio: `0.0405`
- raw_truncated: `False`
- secret_redactions: `0`
- status: `COMPLETE`
