# Failure delta

Status: **NO_PREVIOUS_FAILURE**
Patch key: `patch_firefox_chat_improver_phase63_v0_41_4_manual_snapshot_promotion_v3_20260807_1415 (1)`
Current run: **PASS** (`APPLY`)
Previous failure: `none`

New causes: 2
Resolved causes: 0
Retained causes: 0

## New root causes

- `PTV-RUNNER-001` at `<unknown>` — PASS: Phase 61 full configuration import/restore commits all five global stores together and rolls back on storage failure
- `PTV-RUNNER-001` at `<unknown>` — PASS: Phase 07 monitor transition, re-render, mutation storm and error state
