#!/usr/bin/env python3
"""Phase 63 v0.41.4 hotfix: manual snapshot promotion on the real Phase 62 semantic-dedup baseline."""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd().resolve()
PATCH_NAME = "phase63_v0_41_4_manual_snapshot_promotion_semantic_baseline_hotfix"

sys.path.insert(0, str(ROOT / "tools"))
try:
    from python_patch_utils import backup_file
except Exception as exc:
    print(f"[FAIL] Cannot import patch helper: {exc}", file=sys.stderr)
    raise SystemExit(1)


class PatchError(RuntimeError):
    pass


planned: dict[str, str] = {}


def read(rel: str) -> str:
    path = ROOT / rel
    if not path.is_file():
        raise PatchError(f"Missing required file: {rel}")
    return planned.get(rel, path.read_text(encoding="utf-8"))


def plan(rel: str, text: str) -> None:
    planned[rel] = text


def version_tuple(value: str) -> tuple[int, ...]:
    try:
        return tuple(int(part) for part in str(value).split("."))
    except Exception:
        return (0, 0, 0)


def replace_function(text: str, signature: str, replacement: str, label: str) -> str:
    starts = [m.start() for m in re.finditer(re.escape(signature), text)]
    if len(starts) != 1:
        raise PatchError(f"{label}: expected exactly one {signature!r}, found {len(starts)}")
    start = starts[0]
    brace = text.find("{", start)
    if brace < 0:
        raise PatchError(f"{label}: opening brace not found")
    depth = 0
    quote = None
    escape = False
    i = brace
    while i < len(text):
        ch = text[i]
        if quote is not None:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == quote:
                quote = None
        else:
            if ch in ('"', "'", "`"):
                quote = ch
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return text[:start] + replacement + text[i + 1:]
        i += 1
    raise PatchError(f"{label}: closing brace not found")


def patch_manifest() -> None:
    rel = "extension/manifest.json"
    data = json.loads(read(rel))
    current = version_tuple(data.get("version", "0.0.0"))
    if current < (0, 41, 3):
        raise PatchError(
            f"Phase 63 requires the real Phase 62 v0.41.3 semantic-dedup baseline or newer; found {data.get('version')}"
        )
    if current < (0, 41, 4):
        data["version"] = "0.41.4"
    plan(rel, json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def patch_snapshots() -> None:
    rel = "extension/shared/settings_snapshots.js"
    text = read(rel)
    required = [
        'const ConfigurationBundle = globalThis.FCI_CONFIGURATION_BUNDLE || null;',
        'const MAX_SNAPSHOTS = 20;',
        'function addSnapshot(rawCollection, rawSnapshot)',
    ]
    missing = [marker for marker in required if marker not in text]
    if missing:
        raise PatchError(
            "settings_snapshots.js: real Phase 62 semantic baseline markers missing: " + ", ".join(missing)
        )

    if "const shouldPromoteManual =" not in text:
        start = text.find("function addSnapshot(rawCollection, rawSnapshot)")
        end = text.find("\n  function ", start + 1)
        if start < 0 or end < 0:
            raise PatchError("settings_snapshots.js: addSnapshot structural boundary not found")
        current_fn = text[start:end]
        semantic_markers = [
            "const collection = normalizeCollection(rawCollection);",
            "const snapshot = normalizeSnapshot(rawSnapshot);",
            "item.fingerprint === snapshot.fingerprint",
            "added: false",
            "added: true",
        ]
        missing_fn = [marker for marker in semantic_markers if marker not in current_fn]
        if missing_fn:
            raise PatchError(
                "settings_snapshots.js: addSnapshot does not match the semantic-dedupe contract: "
                + ", ".join(missing_fn)
            )

        replacement = '''function addSnapshot(rawCollection, rawSnapshot) {
    const collection = normalizeCollection(rawCollection);
    const snapshot = normalizeSnapshot(rawSnapshot);
    const existing = collection.snapshots.find((item) => item.fingerprint === snapshot.fingerprint);
    if (existing) {
      const shouldPromoteManual = snapshot.reason === "manual" && existing.reason !== "manual";
      if (shouldPromoteManual) {
        const withoutExisting = collection.snapshots.filter((item) => item.id !== existing.id);
        return {
          collection: normalizeCollection({ snapshots: [snapshot, ...withoutExisting] }),
          snapshot,
          added: true,
          promoted: true
        };
      }
      return {
        collection,
        snapshot: existing,
        added: false,
        promoted: false
      };
    }
    return {
      collection: normalizeCollection({ snapshots: [snapshot, ...collection.snapshots] }),
      snapshot,
      added: true,
      promoted: false
    };
  }'''
        text = replace_function(
            text,
            "function addSnapshot(rawCollection, rawSnapshot)",
            replacement,
            "settings snapshot addSnapshot",
        )

    guard = re.search(r"if \(globalThis\.FCI_SETTINGS_SNAPSHOTS\?\.VERSION >= (\d+)\)", text)
    version = re.search(r"const VERSION = (\d+);", text)
    if not guard or not version:
        raise PatchError("settings_snapshots.js: module guard/VERSION missing")
    if int(guard.group(1)) < 4:
        text = text[: guard.start(1)] + "4" + text[guard.end(1) :]
    version = re.search(r"const VERSION = (\d+);", text)
    if int(version.group(1)) < 4:
        text = text[: version.start(1)] + "4" + text[version.end(1) :]

    final_markers = [
        'const shouldPromoteManual = snapshot.reason === "manual" && existing.reason !== "manual";',
        'const withoutExisting = collection.snapshots.filter((item) => item.id !== existing.id);',
        'collection: normalizeCollection({ snapshots: [snapshot, ...withoutExisting] })',
        'promoted: true',
        'promoted: false',
    ]
    missing = [marker for marker in final_markers if marker not in text]
    if missing:
        raise PatchError("settings_snapshots.js: Phase 63 promotion markers missing: " + ", ".join(missing))
    plan(rel, text)


def create_or_verify(rel: str, content: str) -> None:
    path = ROOT / rel
    if path.exists():
        current = read(rel)
        if current != content:
            raise PatchError(f"Existing generated file differs from corrected Phase 63 target: {rel}")
        plan(rel, content)
    else:
        plan(rel, content)


def patch_metadata() -> None:
    rel = "CHANGELOG.md"
    text = read(rel)
    block = '''## [0.41.4] - 2026-08-07

### Fixed

- A deliberate Manual recovery snapshot now replaces an identical automatic safety snapshot instead of being silently deduplicated away.
- Promotion keeps one semantic-fingerprint entry, records the Manual label/time/id and never lets a later automatic duplicate demote that Manual recovery point.

### Compatibility

- Phase 62 semantic snapshot fingerprinting and the existing bounded `MAX_SNAPSHOTS = 20` policy remain unchanged.
- Protocol remains 26 and Native Host remains 0.13.0.

'''
    if "## [0.41.4] - 2026-08-07" not in text:
        anchors = ["## [0.41.3] - 2026-08-07", "## [0.41.2] - 2026-08-07"]
        selected = next((a for a in anchors if a in text), None)
        if selected is None or text.count(selected) != 1:
            raise PatchError("CHANGELOG.md: preferred Phase 62/61 anchor missing or ambiguous")
        text = text.replace(selected, block + selected, 1)
    plan(rel, text)

    rel = "PROJECT_STATUS.md"
    text = read(rel)
    text = re.sub(
        r"- Current add-on version: \*\*[0-9.]+\*\*",
        "- Current add-on version: **0.41.4**",
        text,
        count=1,
    )
    row = "| Manual snapshot promotion | Manual creation replaces an identical automatic recovery point without duplicate configuration entries or later automatic demotion | **100%** | Completed in v0.41.4 |"
    if row not in text:
        anchor = "| Semantic recovery-snapshot deduplication |"
        if text.count(anchor) != 1:
            raise PatchError(
                f"PROJECT_STATUS.md: semantic recovery row expected once, found {text.count(anchor)}"
            )
        pos = text.index(anchor)
        end = text.find("\n", pos)
        text = text[: end + 1] + row + "\n" + text[end + 1 :]
    plan(rel, text)

    rel = "document/CURRENT_PROJECT_STATUS.md"
    text = read(rel)
    text = re.sub(
        r"\*\*Current baseline:\*\* Phase [0-9]+ v[0-9.]+",
        "**Current baseline:** Phase 63 v0.41.4",
        text,
        count=1,
    )
    block = '''## Phase 63 v0.41.4 — Manual snapshot promotion

- Manual snapshot intent is no longer lost when the same semantic configuration already exists as an automatic safety snapshot.
- The matching automatic entry is replaced by the Manual snapshot while keeping only one fingerprint-equivalent recovery point.
- Later automatic duplicates cannot demote the Manual entry.
- Phase 62 semantic fingerprinting and the existing bounded 20-snapshot retention policy remain unchanged.

'''
    if "## Phase 63 v0.41.4" not in text:
        anchor = "## Phase 62 v0.41.3"
        if text.count(anchor) != 1:
            raise PatchError(
                f"CURRENT_PROJECT_STATUS.md: Phase 62 anchor expected once, found {text.count(anchor)}"
            )
        text = text.replace(anchor, block + anchor, 1)
    text = re.sub(r"Phase 04–[0-9]+ contracts", "Phase 04–63 contracts", text, count=1)
    plan(rel, text)

    rel = "document/PROJECT_IMPLEMENTATION_PLAN.md"
    text = read(rel)
    text = re.sub(
        r"> \*\*Current implementation baseline:\*\* Phase [0-9]+ v[0-9.]+",
        "> **Current implementation baseline:** Phase 63 v0.41.4",
        text,
        count=1,
    )
    if "## Phase 63 — Manual snapshot promotion" not in text:
        text = text.rstrip() + '''

## Phase 63 — Manual snapshot promotion

**Status:** Completed in v0.41.4.

- Preserve deliberate Manual-snapshot intent when Phase 62 semantic deduplication finds an identical automatic safety snapshot.
- Replace/promote the matching automatic entry instead of storing a duplicate configuration copy.
- Prevent later automatic duplicates from demoting the Manual entry.
- Keep the Phase 62 fingerprint semantics and 20-snapshot bounded retention policy unchanged.
''' + "\n"
    plan(rel, text)

    rel = "README.md"
    text = read(rel)
    note = '''
### Manual snapshot promotion

If the current semantic configuration already exists as an automatic safety snapshot, choosing **Create snapshot** replaces that matching automatic entry with the new Manual snapshot instead of silently discarding the user's Manual intent or storing a duplicate. A later automatic snapshot of the same configuration cannot replace the Manual entry. The existing bounded recovery-history size is unchanged.
'''
    if "### Manual snapshot promotion" not in text:
        anchor = "## Complete configuration backup and safe restore"
        if text.count(anchor) != 1:
            raise PatchError(
                f"README.md: complete-configuration recovery anchor expected once, found {text.count(anchor)}"
            )
        pos = text.index(anchor)
        nxt = text.find("\n## ", pos + len(anchor))
        text = text.rstrip() + note + "\n" if nxt < 0 else text[:nxt] + note + text[nxt:]
    plan(rel, text)

    rel = "tools/test_firefox_addon.sh"
    text = read(rel)
    line = "node tests/test_phase63_v0414_manual_snapshot_promotion.js"
    if line not in text:
        anchors = [
            "node tests/test_phase62_v0413_semantic_recovery_snapshot_deduplication.js",
            "node tests/test_phase61_v0412_atomic_full_configuration_commit.js",
        ]
        selected = next((a for a in anchors if a in text), None)
        if selected is None or text.count(selected) != 1:
            raise PatchError("test runner: preferred Phase 62 semantic/Phase 61 anchor missing or ambiguous")
        text = text.replace(selected, selected + "\n" + line, 1)
    if "PASS: FirefoxChatImprover Phase 04-63 v0.41.4 manual snapshot promotion," not in text:
        match = re.search(r"PASS: FirefoxChatImprover Phase 04-[0-9]+ v[0-9.]+ ", text)
        if not match:
            raise PatchError("test runner: final PASS summary prefix not found")
        text = (
            text[: match.start()]
            + "PASS: FirefoxChatImprover Phase 04-63 v0.41.4 manual snapshot promotion, "
            + text[match.end() :]
        )
    plan(rel, text)


def prepare() -> None:
    patch_manifest()
    patch_snapshots()
    create_or_verify(
        "tests/test_phase63_v0414_manual_snapshot_promotion.js",
        '''#!/usr/bin/env node
"use strict";
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const crypto = require("node:crypto");
const root = path.resolve(__dirname, "..");
const settingsSource = fs.readFileSync(path.join(root, "extension/shared/settings.js"), "utf8");
const snapshotsSource = fs.readFileSync(path.join(root, "extension/shared/settings_snapshots.js"), "utf8");
const manifest = JSON.parse(fs.readFileSync(path.join(root, "extension/manifest.json"), "utf8"));
const sandbox = { console, Date, JSON, Math, URL, Uint32Array, crypto: crypto.webcrypto, globalThis: null };
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(settingsSource, sandbox, { filename: "settings.js" });
vm.runInContext(snapshotsSource, sandbox, { filename: "settings_snapshots.js" });
const Settings = sandbox.FCI_SETTINGS;
const Snapshots = sandbox.FCI_SETTINGS_SNAPSHOTS;
assert(Snapshots.VERSION >= 4);
assert.equal(Snapshots.MAX_SNAPSHOTS, 20, "Phase 63 must preserve the real Phase 62 bounded history size");
const base = Settings.defaultStore();
const automatic = Snapshots.makeSnapshot(base, "before_profile_save", "Automatic", {
  id: "auto-same-state", createdAt: "2026-08-07T06:00:00.000Z"
});
let result = Snapshots.addSnapshot({}, automatic);
assert.equal(result.added, true);
assert.equal(result.collection.snapshots.length, 1);
assert.equal(result.collection.snapshots[0].reason, "before_profile_save");
const manual = Snapshots.makeSnapshot(base, "manual", "Manual checkpoint", {
  id: "manual-same-state", createdAt: "2026-08-07T06:01:00.000Z"
});
result = Snapshots.addSnapshot(result.collection, manual);
assert.equal(result.added, true, "manual intent must not be deduplicated away by an automatic snapshot");
assert.equal(result.promoted, true);
assert.equal(result.collection.snapshots.length, 1, "promotion must not duplicate identical configuration");
assert.equal(result.snapshot.id, "manual-same-state");
assert.equal(result.collection.snapshots[0].id, "manual-same-state");
assert.equal(result.collection.snapshots[0].reason, "manual");
const autoAgain = Snapshots.makeSnapshot(base, "before_settings_import", "Automatic again", {
  id: "auto-after-manual", createdAt: "2026-08-07T06:02:00.000Z"
});
result = Snapshots.addSnapshot(result.collection, autoAgain);
assert.equal(result.added, false, "automatic duplicate must not replace/demote an existing manual snapshot");
assert.equal(result.promoted, false);
assert.equal(result.collection.snapshots[0].id, "manual-same-state");
const manualAgain = Snapshots.makeSnapshot(base, "manual", "Manual duplicate", {
  id: "manual-duplicate", createdAt: "2026-08-07T06:03:00.000Z"
});
result = Snapshots.addSnapshot(result.collection, manualAgain);
assert.equal(result.added, false, "manual duplicate of an existing manual point stays deduplicated");
assert.equal(result.promoted, false);
assert.equal(result.collection.snapshots.length, 1);
const parts = manifest.version.split(".").map(Number);
assert(parts[0] > 0 || parts[1] > 41 || (parts[1] === 41 && parts[2] >= 4));
console.log("PASS: Phase 63 promotes an identical automatic semantic recovery point to Manual without changing Phase 62 retention policy");
''',
    )
    create_or_verify(
        "document/PHASE_63_V0_41_4_MANUAL_SNAPSHOT_PROMOTION.md",
        '''# Phase 63 v0.41.4 — Manual snapshot promotion

Phase 62 introduced semantic recovery-snapshot deduplication while retaining the existing bounded 20-snapshot history. Phase 63 fixes one remaining intent issue: if an identical semantic configuration already exists as an automatic safety snapshot, creating a Manual snapshot replaces that automatic entry with the new Manual snapshot rather than silently returning the automatic entry. The fingerprint-equivalent configuration remains stored once, and later automatic duplicates cannot demote the Manual entry.
''',
    )
    patch_metadata()


def apply() -> list[str]:
    changed: list[str] = []
    for rel, target in planned.items():
        path = ROOT / rel
        current = path.read_text(encoding="utf-8") if path.is_file() else None
        if current == target:
            print(f"unchanged/check: {rel}")
            continue
        if path.is_file():
            backup_file(ROOT, rel, PATCH_NAME)
            print(f"patched: {rel}")
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            print(f"created: {rel}")
        path.write_text(target, encoding="utf-8")
        changed.append(rel)
    return changed


def run(cmd: list[str], label: str) -> None:
    print(f"CHECK: {label}")
    result = subprocess.run(cmd, cwd=ROOT)
    if result.returncode:
        raise PatchError(f"{label} failed with exit code {result.returncode}")


def validate(changed: list[str]) -> None:
    if not changed:
        print("CHECK: corrected Phase 63 already applied; no commands run because no files changed.")
        return
    run(["node", "--check", "extension/shared/settings_snapshots.js"], "settings snapshot module syntax")
    run(["bash", "-n", "tools/test_firefox_addon.sh"], "test runner shell syntax")
    run(["node", "tests/test_phase63_v0414_manual_snapshot_promotion.js"], "Phase 63 manual-promotion contract")
    for test in [
        "tests/test_phase19_settings_snapshots.js",
        "tests/test_phase62_v0413_semantic_recovery_snapshot_deduplication.js",
        "tests/test_phase58_v0409_complete_configuration_backup.js",
        "tests/test_phase61_v0412_atomic_full_configuration_commit.js",
    ]:
        if (ROOT / test).is_file():
            run(["node", test], Path(test).name)
    if (ROOT / "tests/test_phase42_v0393_release_status_consistency.py").is_file():
        run(
            ["python3", "tests/test_phase42_v0393_release_status_consistency.py"],
            "Phase 42 release consistency",
        )
    if (ROOT / "tools/check_source_syntax.py").is_file():
        run(["bash", "tools/test_firefox_addon.sh"], "Phase 04-63 full regression")
    else:
        print("SKIP: full regression unavailable in reconstructed source; complete repo will run it.")


try:
    prepare()
    changed = apply()
    validate(changed)
    print(
        f"[PASS] Corrected Phase 63 v0.41.4 manual snapshot promotion on semantic Phase 62 baseline (changed={len(changed)})"
    )
except Exception as exc:
    print(f"[FAIL] {type(exc).__name__}: {exc}", file=sys.stderr)
    raise SystemExit(1)
