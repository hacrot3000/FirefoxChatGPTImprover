# Root-cause candidates

Primary candidates: 2
Secondary/duplicate failures suppressed: 0

## ROOT-01 — `PTV-RUNNER-001`

- Location: `<not detected>`
- Message: PASS: Phase 07 monitor transition, re-render, mutation storm and error state
- Suggested action: Inspect the referenced code context and the first preceding error; later failures may be cascading.
- Repeated occurrences: 1

## ROOT-02 — `PTV-RUNNER-001`

- Location: `<not detected>`
- Message: PASS: Phase 61 full configuration import/restore commits all five global stores together and rolls back on storage failure
- Suggested action: Inspect the referenced code context and the first preceding error; later failures may be cascading.
- Repeated occurrences: 1
