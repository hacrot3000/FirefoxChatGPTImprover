# AI handoff token budget

- Policy: `TOKEN_BOUNDED_SEMANTIC_SAFE`
- HANDOFF: `24149` / `24000` estimated tokens; omitted `17`; compacted `1`
- SUMMARY: `0` / `10000` estimated tokens; omitted `0`; compacted `0`
- CODE: `0` / `28000` estimated tokens; omitted `0`; compacted `0`

DETAIL.zip remains the complete redacted evidence archive and is intentionally not token-bounded.
If HANDOFF omits required evidence, send DETAIL only when the AI asks for the omitted raw material.
