# Diagnostic quality

- tool_version: `5.16.0`
- structured_diagnostic_count: `0`
- root_cause_count: `0`
- secondary_suppressed: `0`
- raw_lines: `8`
- important_lines: `7`
- reduction_ratio: `0.125`
- raw_truncated: `False`
- secret_redactions: `0`
- status: `COMPLETE`
