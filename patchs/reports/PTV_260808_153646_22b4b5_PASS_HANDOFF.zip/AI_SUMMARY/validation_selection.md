# Validation impact selection

Status: **DISABLED**
Mode: `off`
Changed paths considered: 17
Requested profiles: none
Automatically selected: none
Final profiles: none

No path rule matched the patch delta.
