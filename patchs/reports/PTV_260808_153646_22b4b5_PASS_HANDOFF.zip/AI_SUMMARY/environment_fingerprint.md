# Environment fingerprint

- OS: `Linux 6.8.0-136-generic (x86_64)`
- Python: `3.10.12`
- Git HEAD: `724de2b505aa`
- Git branch: `main`
- Dirty before report: `True`
- Tool probe cache used: `True`

## Tools

- `cmake`: cmake version 3.22.1 | CMake suite maintained and supported by Kitware (kitware.com/cmake).
- `docker`: Docker version 28.1.1, build 4eba377
- `gcc`: gcc (Ubuntu 9.5.0-1ubuntu1~22.04.1) 9.5.0 | Copyright (C) 2019 Free Software Foundation, Inc. | This is free software; see the source for copying conditions.  There is NO
- `git`: git version 2.34.1
- `go`: go version go1.20.14 linux/amd64
- `java`: openjdk version "19.0.2" 2023-01-17 | OpenJDK Runtime Environment (build 19.0.2+7-Ubuntu-0ubuntu322.04) | OpenJDK 64-Bit Server VM (build 19.0.2+7-Ubuntu-0ubuntu322.04, mixed mode, sharing)
- `ninja`: 1.10.1
- `node`: v20.19.5
- `python`: Python 3.10.12
- `rustc`: rustc 1.93.0 (254b59607 2026-01-19)
