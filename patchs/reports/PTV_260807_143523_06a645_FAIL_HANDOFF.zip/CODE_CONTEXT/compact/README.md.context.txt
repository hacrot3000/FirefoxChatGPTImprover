  L 1: # FirefoxChatImprover
  L 2: 
  L 3: ## ⚡ Cài đặt nhanh (không cần build)
  L 4: 
  L 5: > Tải bản đã build sẵn từ GitHub Releases — **không cần Node.js, Python hay bất kỳ công cụ nào**.
  L 6: 
  L 7: ### Bước 1 — Tải file `.zip`
  L 8: 
  L 9: Vào trang **[Releases](../../releases)** của repository này, chọn phiên bản mới nhất rồi tải file:
  L10: 
  L11: ```
  L12: firefox-chat-ai-assistant-<version>-unsigned.zip
  L13: ```
  L14: 
  L15: > **Kiểm tra toàn vẹn (tùy chọn):** Mỗi release kèm file `SHA256SUMS`, bạn có thể xác minh bằng:
  L16: > ```bash
  L17: > sha256sum -c SHA256SUMS
  L18: > ```
  L19: 
  L20: ### Bước 2 — Cài vào Firefox
  L21: 
  L22: 1. Mở Firefox, vào địa chỉ: **`about:addons`**
  L23: 2. Nhấn biểu tượng bánh răng ⚙️ → chọn **"Install Add-on From File..."**
  L24: 3. Chọn file `.zip` vừa tải về → nhấn **Add**
  L25: 
  L26: > **Lưu ý:** Đây là bản chưa qua Mozilla ký (unsigned). Firefox sẽ cho phép cài trên **Firefox Developer Edition** hoặc **Firefox ESR** với `xpinstall.signatures.required = false` trong `about:config`.  
  L27: > Để cài lâu dài trên Firefox Release thông thường, cần bản XPI đã được Mozilla ký qua AMO.
  L28: 
  L29: ### Bước 3 — Cài Native Host (nếu dùng tính năng Shell command)
  L30: 
  L31: ```bash
  L32: git clone <repository-url>
  L33: cd FirefoxChatImprover
  L34: ./native-host/install_native_host.sh
  L35: ```
  L36: 
  L37: Sau đó reload add-on trong `about:addons`.
  L38: 
  L39: ---
  L40: 
  L41: ## Complete configuration backup and safe restore
