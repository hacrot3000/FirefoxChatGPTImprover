#!/usr/bin/env python3
# Phase 61 v0.41.2 — atomic full configuration commit
from __future__ import annotations
import json,re,subprocess,sys
from pathlib import Path
ROOT=Path.cwd().resolve(); PATCH_NAME="phase61_v0_41_2_atomic_full_configuration_commit"
sys.path.insert(0,str(ROOT/"tools"))
try:
    from python_patch_utils import backup_file
except Exception as exc:
    print(f"[FAIL] Cannot import patch helper: {exc}",file=sys.stderr); raise SystemExit(1)
class PatchError(RuntimeError): pass
planned={}
def read(rel):
    p=ROOT/rel
    if not p.is_file(): raise PatchError(f"Missing required file: {rel}")
    return p.read_text(encoding="utf-8")
def plan(rel,text): planned[rel]=text
def replace_once(text,old,new,label):
    if new in text: return text
    count=text.count(old)
    if count!=1: raise PatchError(f"{label}: expected Phase 60 block once, found {count}")
    return text.replace(old,new,1)
def ensure_created(rel,target):
    p=ROOT/rel
    if p.exists():
        current=read(rel)
        if current!=target: raise PatchError(f"{rel} already exists with unexpected content")
        plan(rel,current)
    else: plan(rel,target)
def prepare():
    # Transactional preflight: prepare every target before writing any file.
    rel="extension/manifest.json"; data=json.loads(read(rel)); version=str(data.get("version") or "")
    if version not in {"0.41.1","0.41.2"}: raise PatchError(f"{rel}: expected v0.41.1 or v0.41.2, found {version}")
    data["version"]="0.41.2"; plan(rel,json.dumps(data,indent=2,ensure_ascii=False)+"\n")

    rel="extension/background/background.js"; text=read(rel)
    text=replace_once(text,'  async function replaceFullConfigurationBundle(bundle, reason = "Full configuration replacement") {\n    const normalized = ConfigurationBundle.normalizeBundle(bundle);\n    const [previousAutomationStore, previousLocalActionStore] = await Promise.all([\n      loadStore(),\n      loadLocalActionStore()\n    ]);\n    const savedAutomationStore = await saveStore(normalized.automationStore);\n    const savedLocalActionStore = await saveLocalActionStore(normalized.localActionStore);\n    await Promise.all([\n      saveCommandPresetStore(normalized.commandPresetStore),\n      PromptTemplates.saveStore(browser, normalized.promptTemplateStore),\n      saveSidebarPreferences(normalized.sidebarPreferences)\n    ]);\n    const [automationPreservation, localActionPreservation] = await Promise.all([\n      refreshSessionsForStore(previousAutomationStore, savedAutomationStore, reason),\n      refreshSessionsForLocalActionStore(previousLocalActionStore, savedLocalActionStore, reason)\n    ]);\n    return {\n      store: savedAutomationStore,\n      localActionStore: savedLocalActionStore,\n      automationPreservation,\n      localActionPreservation\n    };\n  }\n\n','  async function commitFullConfigurationBundle(bundle) {\n    const normalized = ConfigurationBundle.normalizeBundle(bundle);\n    const [previousAutomationStore, previousLocalActionStore, previousCommandPresetStore, previousPromptTemplateStore, sidebarResult] = await Promise.all([\n      loadStore(),\n      loadLocalActionStore(),\n      loadCommandPresetStore(),\n      PromptTemplates.loadStore(browser),\n      browser.storage.local.get(ConfigurationBundle.SIDEBAR_UI_STORAGE_KEY)\n    ]);\n\n    const savedAutomationStore = Settings.normalizeStore(normalized.automationStore);\n    savedAutomationStore.revision += 1;\n    const savedLocalActionStore = LocalActions.normalizeStore(normalized.localActionStore);\n    savedLocalActionStore.revision += 1;\n    const savedCommandPresetStore = CommandPresets.normalizeStore(normalized.commandPresetStore);\n    const savedPromptTemplateStore = PromptTemplates.normalizeStore(normalized.promptTemplateStore);\n    const preferences = ConfigurationBundle.normalizeSidebarPreferences(normalized.sidebarPreferences);\n    const existingSidebarPreferences = sidebarResult[ConfigurationBundle.SIDEBAR_UI_STORAGE_KEY] && typeof sidebarResult[ConfigurationBundle.SIDEBAR_UI_STORAGE_KEY] === "object"\n      ? sidebarResult[ConfigurationBundle.SIDEBAR_UI_STORAGE_KEY]\n      : {};\n    const savedSidebarPreferences = {\n      ...existingSidebarPreferences,\n      collapsedGroups: preferences.collapsedGroups,\n      featurePreset: preferences.featurePreset,\n      visibleFeatures: preferences.visibleFeatures,\n      autoProfileByUrl: preferences.autoProfileByUrl\n    };\n\n    const nextPayload = {\n      [Settings.STORAGE_KEY]: savedAutomationStore,\n      [LocalActions.STORAGE_KEY]: savedLocalActionStore,\n      [CommandPresets.STORAGE_KEY]: savedCommandPresetStore,\n      [PromptTemplates.STORAGE_KEY]: savedPromptTemplateStore,\n      [ConfigurationBundle.SIDEBAR_UI_STORAGE_KEY]: savedSidebarPreferences\n    };\n    const rollbackPayload = {\n      [Settings.STORAGE_KEY]: previousAutomationStore,\n      [LocalActions.STORAGE_KEY]: previousLocalActionStore,\n      [CommandPresets.STORAGE_KEY]: previousCommandPresetStore,\n      [PromptTemplates.STORAGE_KEY]: previousPromptTemplateStore,\n      [ConfigurationBundle.SIDEBAR_UI_STORAGE_KEY]: existingSidebarPreferences\n    };\n\n    try {\n      // One storage write keeps the five reusable/global configuration stores on one commit boundary.\n      await browser.storage.local.set(nextPayload);\n    } catch (error) {\n      // Storage-provider failures can be ambiguous. Restore the previous coherent\n      // five-store payload before surfacing the error whenever rollback is possible.\n      try {\n        await browser.storage.local.set(rollbackPayload);\n      } catch (rollbackError) {\n        throw new Error(`Full configuration commit failed and rollback also failed: ${error instanceof Error ? error.message : String(error)}; rollback: ${rollbackError instanceof Error ? rollbackError.message : String(rollbackError)}`);\n      }\n      throw new Error(`Full configuration commit failed; previous configuration was restored: ${error instanceof Error ? error.message : String(error)}`);\n    }\n\n    // Do not advance in-memory caches until the multi-key storage commit succeeds.\n    storePromise = Promise.resolve(savedAutomationStore);\n    localActionStorePromise = Promise.resolve(savedLocalActionStore);\n    return {\n      previousAutomationStore,\n      previousLocalActionStore,\n      savedAutomationStore: clone(savedAutomationStore),\n      savedLocalActionStore: LocalActions.clone(savedLocalActionStore),\n      savedCommandPresetStore: CommandPresets.clone(savedCommandPresetStore),\n      savedPromptTemplateStore: PromptTemplates.clone(savedPromptTemplateStore),\n      savedSidebarPreferences: ConfigurationBundle.clone(preferences)\n    };\n  }\n\n  async function replaceFullConfigurationBundle(bundle, reason = "Full configuration replacement") {\n    const committed = await commitFullConfigurationBundle(bundle);\n    const [automationPreservation, localActionPreservation] = await Promise.all([\n      refreshSessionsForStore(committed.previousAutomationStore, committed.savedAutomationStore, reason),\n      refreshSessionsForLocalActionStore(committed.previousLocalActionStore, committed.savedLocalActionStore, reason)\n    ]);\n    return {\n      store: committed.savedAutomationStore,\n      localActionStore: committed.savedLocalActionStore,\n      automationPreservation,\n      localActionPreservation\n    };\n  }\n\n',"full configuration commit boundary")
    plan(rel,text)

    ensure_created("tests/test_phase61_v0412_atomic_full_configuration_commit.js",'#!/usr/bin/env node\n"use strict";\nconst assert = require("node:assert/strict");\nconst fs = require("node:fs");\nconst path = require("node:path");\nconst root = path.resolve(__dirname, "..");\nconst read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");\nconst manifest = JSON.parse(read("extension/manifest.json"));\nconst background = read("extension/background/background.js");\nfunction versionAtLeast(actual, minimum) {\n  const a = String(actual).split(".").map(Number), b = String(minimum).split(".").map(Number);\n  for (let i = 0; i < Math.max(a.length, b.length); i += 1) {\n    const av = a[i] || 0, bv = b[i] || 0;\n    if (av !== bv) return av > bv;\n  }\n  return true;\n}\nassert(versionAtLeast(manifest.version, "0.41.2"));\nassert(background.includes("async function commitFullConfigurationBundle(bundle)"));\nfor (const key of [\n  "[Settings.STORAGE_KEY]: savedAutomationStore",\n  "[LocalActions.STORAGE_KEY]: savedLocalActionStore",\n  "[CommandPresets.STORAGE_KEY]: savedCommandPresetStore",\n  "[PromptTemplates.STORAGE_KEY]: savedPromptTemplateStore",\n  "[ConfigurationBundle.SIDEBAR_UI_STORAGE_KEY]: savedSidebarPreferences"\n]) assert(background.includes(key), `missing commit payload key: ${key}`);\nconst commitStart = background.indexOf("async function commitFullConfigurationBundle(bundle)");\nconst replaceStart = background.indexOf("async function replaceFullConfigurationBundle", commitStart);\nconst commit = background.slice(commitStart, replaceStart);\nassert.equal((commit.match(/await browser\\.storage\\.local\\.set\\(nextPayload\\)/g) || []).length, 1);\nassert(commit.includes("await browser.storage.local.set(rollbackPayload)"));\nassert(commit.indexOf("storePromise = Promise.resolve(savedAutomationStore)") > commit.indexOf("await browser.storage.local.set(nextPayload)"));\nassert(commit.indexOf("localActionStorePromise = Promise.resolve(savedLocalActionStore)") > commit.indexOf("await browser.storage.local.set(nextPayload)"));\nconst replace = background.slice(replaceStart, background.indexOf("async function previewSettingsImport", replaceStart));\nfor (const legacyCall of [\n  "await saveStore(normalized.automationStore)",\n  "await saveLocalActionStore(normalized.localActionStore)",\n  "saveCommandPresetStore(normalized.commandPresetStore)",\n  "PromptTemplates.saveStore(browser, normalized.promptTemplateStore)",\n  "saveSidebarPreferences(normalized.sidebarPreferences)"\n]) assert(!replace.includes(legacyCall), `sequential full-replacement write survived: ${legacyCall}`);\nassert(replace.includes("const committed = await commitFullConfigurationBundle(bundle)"));\nassert(replace.includes("refreshSessionsForStore(committed.previousAutomationStore, committed.savedAutomationStore, reason)"));\nassert(replace.includes("refreshSessionsForLocalActionStore(committed.previousLocalActionStore, committed.savedLocalActionStore, reason)"));\nconsole.log("PASS: Phase 61 full configuration import/restore commits all five global stores together and rolls back on storage failure");\n')
    ensure_created("document/PHASE_61_V0_41_2_ATOMIC_FULL_CONFIGURATION_COMMIT.md",'# Phase 61 v0.41.2 — Atomic full configuration commit\n\nFull configuration import and full recovery-snapshot restore now prepare Automation, Local action, command-preset, prompt-template and sidebar-preference stores first and write all five keys in one `browser.storage.local.set(...)` call. In-memory Automation/Local-action caches are updated only after that commit succeeds.\n\nIf the storage provider rejects the commit, the background makes a best-effort rollback to the previous coherent five-store payload and returns an error instead of intentionally continuing with a partially replaced global configuration. Existing active/stopped-tab safe-detach reconciliation runs only after the global commit succeeds.\n')

    rel="CHANGELOG.md"; text=read(rel)
    block='## [0.41.2] - 2026-08-07\n\n### Fixed\n\n- Full configuration import and full recovery-snapshot restore no longer write Automation, Local action, command-preset, prompt-template and sidebar-preference stores in separate sequential commits.\n- A failed multi-key configuration commit now attempts to restore the previous coherent global configuration payload before returning an error.\n\n### Safety\n\n- Automation and Local action runtime caches advance only after storage succeeds; active/stopped-tab safe-detach reconciliation still runs after a successful commit.\n\n### Compatibility\n\n- Protocol remains 26 and Native Host remains 0.13.0.\n\n'
    if "## [0.41.2] - 2026-08-07" not in text:
        anchor="## [0.41.1] - 2026-08-07"
        if text.count(anchor)!=1: raise PatchError("CHANGELOG.md: Phase 60 anchor missing or ambiguous")
        text=text.replace(anchor,block+anchor,1)
    plan(rel,text)

    rel="PROJECT_STATUS.md"; text=read(rel)
    text=re.sub(r"- Current add-on version: \*\*[0-9.]+\*\*","- Current add-on version: **0.41.2**",text,count=1)
    row="| Atomic full-configuration commit | One multi-key storage commit for all reusable/global configuration stores with best-effort rollback on failure | **100%** | Completed in v0.41.2 |"
    if row not in text:
        anchor="| Configuration import preview |"; pos=text.find(anchor)
        if pos<0: raise PatchError("PROJECT_STATUS.md: Phase 60 row missing")
        end=text.find("\n",pos); text=text[:end+1]+row+"\n"+text[end+1:]
    plan(rel,text)

    rel="document/CURRENT_PROJECT_STATUS.md"; text=read(rel)
    text=re.sub(r"\*\*Current baseline:\*\* Phase [0-9]+ v[0-9.]+","**Current baseline:** Phase 61 v0.41.2",text,count=1)
    text=text.replace("Phase 04–60 contracts","Phase 04–61 contracts")
    block='## Phase 61 v0.41.2 — Atomic full configuration commit\n\nFull configuration import/restore now writes the five reusable/global configuration stores on one storage commit boundary. If the provider rejects the write, the previous coherent payload is restored on a best-effort basis before the error is surfaced. Runtime caches are not advanced before storage succeeds.\n\n'
    if "## Phase 61 v0.41.2" not in text:
        anchor="## Phase 60 v0.41.1"
        if text.count(anchor)!=1: raise PatchError("CURRENT_PROJECT_STATUS.md: Phase 60 anchor missing or ambiguous")
        text=text.replace(anchor,block+anchor,1)
    plan(rel,text)

    rel="document/PROJECT_IMPLEMENTATION_PLAN.md"; text=read(rel)
    text=re.sub(r"> \*\*Current implementation baseline:\*\* Phase [0-9]+ v[0-9.]+","> **Current implementation baseline:** Phase 61 v0.41.2",text,count=1)
    if "## Phase 61 — Atomic full configuration commit" not in text:
        text=text.rstrip()+'\n\n## Phase 61 — Atomic full configuration commit\n\n**Status:** Completed in v0.41.2.\n\n- Prepare all five reusable/global configuration stores before mutation.\n- Commit Automation, Local action, command presets, prompt templates and sidebar preferences in one multi-key storage write.\n- Update in-memory caches only after storage succeeds and attempt rollback to the previous coherent payload if the provider rejects the commit.\n- Run existing active/stopped-tab safe-detach reconciliation after a successful global commit.\n'+"\n"
    plan(rel,text)

    rel="README.md"; text=read(rel)
    note='### Atomic full-configuration storage commit\n\nFull configuration import and full recovery restore prepare Automation, Local action, command presets, prompt templates and sidebar preferences before mutation, then write the five storage keys together. In-memory Automation/Local-action caches update only after storage succeeds. If the provider rejects the commit, the previous coherent payload is restored on a best-effort basis and the operation reports an error.\n\n'
    if "### Atomic full-configuration storage commit" not in text:
        marker="### Preview before configuration import"
        pos=text.find(marker)
        if pos<0: raise PatchError("README.md: Phase 60 preview section missing")
        text=text[:pos]+note+text[pos:]
    plan(rel,text)

    rel="tools/test_firefox_addon.sh"; text=read(rel)
    line="node tests/test_phase61_v0412_atomic_full_configuration_commit.js"
    if line not in text:
        anchor="node tests/test_phase60_v0411_configuration_import_preview_confirmation.js"
        if text.count(anchor)!=1: raise PatchError("test runner: Phase 60 anchor missing or ambiguous")
        text=text.replace(anchor,anchor+"\n"+line,1)
    text=text.replace("PASS: FirefoxChatImprover Phase 04-60 v0.41.1 configuration import preview, configuration scope return contract,","PASS: FirefoxChatImprover Phase 04-61 v0.41.2 atomic full-configuration commit, configuration import preview, configuration scope return contract,")
    plan(rel,text)

def apply():
    changed=[]
    for rel,target in planned.items():
        p=ROOT/rel; current=p.read_text(encoding="utf-8") if p.is_file() else None
        if current==target:
            print(f"unchanged/check: {rel}"); continue
        if p.is_file():
            backup_file(ROOT,rel,PATCH_NAME); print(f"patched: {rel}")
        else:
            p.parent.mkdir(parents=True,exist_ok=True); print(f"created: {rel}")
        p.write_text(target,encoding="utf-8"); changed.append(rel)
    return changed

def run(cmd,label):
    print(f"CHECK: {label}")
    r=subprocess.run(cmd,cwd=ROOT)
    if r.returncode: raise PatchError(f"{label} failed with exit code {r.returncode}")

def validate(changed):
    if not changed:
        print("CHECK: Phase 61 already applied; no commands run because no files changed."); return
    run(["node","--check","extension/background/background.js"],"background JavaScript syntax")
    run(["bash","-n","tools/test_firefox_addon.sh"],"test runner shell syntax")
    focused=[
      "tests/test_phase49_v0400_safe_profile_lifecycle.js",
      "tests/test_phase50_v0401_local_action_profile_save_draft_continuity.js",
      "tests/test_phase51_v0402_component_profile_editor_draft_continuity.js",
      "tests/test_phase52_v0403_non_destructive_profile_bundle_import.js",
      "tests/test_phase53_v0404_explicit_default_profile_controls.js",
      "tests/test_phase54_v0405_component_default_profile_controls.js",
      "tests/test_phase55_v0406_profile_action_clarity.js",
      "tests/test_phase56_v0407_working_session_profile_isolation.js",
      "tests/test_phase57_v0408_safe_configuration_restore.js",
      "tests/test_phase58_v0409_complete_configuration_backup.js",
      "tests/test_phase59_v0410_configuration_scope_return_contract.js",
      "tests/test_phase60_v0411_configuration_import_preview_confirmation.js",
      "tests/test_phase61_v0412_atomic_full_configuration_commit.js",
    ]
    for test in focused: run(["node",test],Path(test).name)
    run(["python3","tests/test_phase42_v0393_release_status_consistency.py"],"Phase 42 release-status consistency")
    if (ROOT/"tools/check_source_syntax.py").is_file():
        run(["bash","tools/test_firefox_addon.sh"],"Phase 04-61 full regression")
    else:
        print("SKIP: full regression unavailable in reconstructed source; complete repo will run it.")
try:
    prepare(); changed=apply(); validate(changed)
    print(f"[PASS] Phase 61 v0.41.2 atomic full configuration commit (changed={len(changed)})")
except Exception as exc:
    print(f"[FAIL] {type(exc).__name__}: {exc}",file=sys.stderr); raise SystemExit(1)
