# Failure delta

Status: **SAME_FAILURE**
Patch key: `patch_firefox_chat_improver_phase63_v0_41_4_manual_snapshot_promotion_v3_20260807_1415`
Current run: **FAIL** (`APPLY`)
Previous failure: `2026-08-07T14:13:23+07:00`

New causes: 0
Resolved causes: 0
Retained causes: 1

## Retained root causes

- `PTV-RUNNER-001` at `<unknown>` — Stopping package after failed patch: patchs/patch_firefox_chat_improver_phase63_v0_41_4_manual_snapshot_promotion_v3_20260807_1415.zip::patch_firefox_chat_improver_phase63_v0_41_4_manual_snapshot_promotion_v3_20260807_1415.py

The primary failure is unchanged. Avoid resending unchanged raw logs; update the patch using current code context.
