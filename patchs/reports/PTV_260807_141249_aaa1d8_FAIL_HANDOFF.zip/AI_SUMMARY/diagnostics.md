# Diagnostics

## 1. ERROR — package

- Location: `<not detected>`
- Message: Stopping package after failed patch: patchs/patch_firefox_chat_improver_phase63_v0_41_4_manual_snapshot_promotion_v3_20260807_1415.zip::patch_firefox_chat_improver_phase63_v0_41_4_manual_snapshot_promotion_v3_20260807_1415.py
- Suggested next check: Inspect the first structured diagnostic and important log before the final package error.
- Source: `runner`

```text
Stopping package after failed patch: patchs/patch_firefox_chat_improver_phase63_v0_41_4_manual_snapshot_promotion_v3_20260807_1415.zip::patch_firefox_chat_improver_phase63_v0_41_4_manual_snapshot_promotion_v3_20260807_1415.py
```
