#!/usr/bin/env python3
"""Phase 63 v0.41.4: manual snapshot intent promotes matching automatic recovery points."""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd().resolve()
PATCH_NAME = "phase63_v0_41_4_manual_snapshot_promotion"

sys.path.insert(0, str(ROOT / "tools"))
try:
    from python_patch_utils import backup_file
except Exception as exc:
    print(f"[FAIL] Cannot import patch helper: {exc}", file=sys.stderr)
    raise SystemExit(1)


class PatchError(RuntimeError):
    pass


planned: dict[str, str] = {}


def read(rel: str) -> str:
    path = ROOT / rel
    if not path.is_file():
        raise PatchError(f"Missing required file: {rel}")
    return planned.get(rel, path.read_text(encoding="utf-8"))


def plan(rel: str, text: str) -> None:
    planned[rel] = text


def version_tuple(value: str) -> tuple[int, ...]:
    try:
        return tuple(int(part) for part in str(value).split("."))
    except Exception:
        return (0, 0, 0)


def patch_manifest() -> None:
    rel = "extension/manifest.json"
    data = json.loads(read(rel))
    current = version_tuple(data.get("version", "0.0.0"))
    if current < (0, 41, 3):
        raise PatchError(f"Phase 63 requires Phase 62 v0.41.3 or newer; found {data.get('version')}")
    if current < (0, 41, 4):
        data["version"] = "0.41.4"
    plan(rel, json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def patch_snapshots() -> None:
    rel = "extension/shared/settings_snapshots.js"
    text = read(rel)
    phase62_required = [
        "const MAX_AUTOMATIC_SNAPSHOTS = 20;",
        "const MAX_MANUAL_SNAPSHOTS = 10;",
        "function snapshotRetentionClass(rawSnapshot)",
        "function retainSnapshots(rawSnapshots)",
        "snapshots: retainSnapshots(snapshots)",
    ]
    missing = [item for item in phase62_required if item not in text]
    if missing:
        raise PatchError("settings_snapshots.js: Phase 62 baseline markers missing: " + ", ".join(missing))

    promoted_marker = "const shouldPromoteToManual ="
    if promoted_marker not in text:
        # Bump module generation while remaining forward-safe if a later version already exists.
        text, n = re.subn(
            r"if \(globalThis\.FCI_SETTINGS_SNAPSHOTS\?\.VERSION >= 3\)",
            "if (globalThis.FCI_SETTINGS_SNAPSHOTS?.VERSION >= 4)",
            text,
            count=1,
        )
        if n == 0:
            # Later version guard is acceptable; do not downgrade it.
            if not re.search(r"if \(globalThis\.FCI_SETTINGS_SNAPSHOTS\?\.VERSION >= [4-9][0-9]*\)", text):
                raise PatchError("settings_snapshots.js: Phase 62/forward module guard not found")
        text, n = re.subn(r"const VERSION = 3;", "const VERSION = 4;", text, count=1)
        if n == 0 and not re.search(r"const VERSION = ([4-9]|[1-9][0-9]+);", text):
            raise PatchError("settings_snapshots.js: Phase 62/forward VERSION constant not found")

        pattern = re.compile(
            r"  function addSnapshot\(rawCollection, rawSnapshot\) \{\n"
            r"    const collection = normalizeCollection\(rawCollection\);\n"
            r"    const snapshot = normalizeSnapshot\(rawSnapshot\);\n"
            r"    const existing = collection\.snapshots\.find\(\(item\) => item\.fingerprint === snapshot\.fingerprint\);\n"
            r"    if \(existing\) \{\n"
            r"      return \{\n"
            r"        collection,\n"
            r"        snapshot: existing,\n"
            r"        added: false\n"
            r"      \};\n"
            r"    \}\n"
            r"    return \{\n"
            r"      collection: normalizeCollection\(\{ snapshots: \[snapshot, \.\.\.collection\.snapshots\] \}\),\n"
            r"      snapshot,\n"
            r"      added: true\n"
            r"    \};\n"
            r"  \}"
        )
        replacement = '''  function addSnapshot(rawCollection, rawSnapshot) {
    const collection = normalizeCollection(rawCollection);
    const snapshot = normalizeSnapshot(rawSnapshot);
    const existing = collection.snapshots.find((item) => item.fingerprint === snapshot.fingerprint);
    if (existing) {
      const shouldPromoteToManual = snapshotRetentionClass(snapshot) === "manual"
        && snapshotRetentionClass(existing) !== "manual";
      if (shouldPromoteToManual) {
        const withoutExisting = collection.snapshots.filter((item) => item.id !== existing.id);
        return {
          collection: normalizeCollection({ snapshots: [snapshot, ...withoutExisting] }),
          snapshot,
          added: true,
          promoted: true
        };
      }
      return {
        collection,
        snapshot: existing,
        added: false,
        promoted: false
      };
    }
    return {
      collection: normalizeCollection({ snapshots: [snapshot, ...collection.snapshots] }),
      snapshot,
      added: true,
      promoted: false
    };
  }'''
        text, n = pattern.subn(replacement, text, count=1)
        if n != 1:
            raise PatchError(f"settings_snapshots.js: legacy addSnapshot block expected once, found {n}")

    required = [
        'const shouldPromoteToManual = snapshotRetentionClass(snapshot) === "manual"',
        '&& snapshotRetentionClass(existing) !== "manual";',
        'const withoutExisting = collection.snapshots.filter((item) => item.id !== existing.id);',
        'collection: normalizeCollection({ snapshots: [snapshot, ...withoutExisting] })',
        'promoted: true',
        'promoted: false',
    ]
    missing = [item for item in required if item not in text]
    if missing:
        raise PatchError("settings_snapshots.js: Phase 63 markers missing: " + ", ".join(missing))
    plan(rel, text)


def patch_phase19_contract() -> None:
    rel = "tests/test_phase19_settings_snapshots.js"
    text = read(rel)
    new = '''assert.equal(Snapshots.MAX_AUTOMATIC_SNAPSHOTS, 20);
assert.equal(Snapshots.MAX_MANUAL_SNAPSHOTS, 10);
assert.equal(Snapshots.MAX_SNAPSHOTS, 30);'''
    if new not in text:
        old = "assert.equal(Snapshots.MAX_SNAPSHOTS, 20);"
        if text.count(old) != 1:
            raise PatchError(
                f"Phase 19 snapshot-capacity assertion source missing/ambiguous; matches={text.count(old)}"
            )
        text = text.replace(old, new, 1)
    old_retention = """assert.equal(collection.snapshots.length, 20);
assert.equal(collection.snapshots[0].label, "Snapshot 24");
assert.equal(collection.snapshots.at(-1).label, "Snapshot 5");

const removed = Snapshots.removeSnapshot(collection, collection.snapshots[0].id);
assert.equal(removed.snapshots.length, 19);"""
    new_retention = """assert.equal(collection.snapshots.length, 21);
const retainedManual = collection.snapshots.filter((snapshot) => Snapshots.snapshotRetentionClass(snapshot) === "manual");
const retainedAutomatic = collection.snapshots.filter((snapshot) => Snapshots.snapshotRetentionClass(snapshot) === "automatic");
assert.equal(retainedManual.length, 1);
assert.equal(retainedAutomatic.length, 20);
assert.equal(collection.snapshots[0].label, "Snapshot 24");
assert.equal(retainedAutomatic.at(-1).label, "Snapshot 5");
assert.equal(retainedManual[0].label, "First");

const removed = Snapshots.removeSnapshot(collection, collection.snapshots[0].id);
assert.equal(removed.snapshots.length, 20);"""
    if new_retention not in text:
        if text.count(old_retention) != 1:
            raise PatchError(
                f"Phase 19 old retention-behavior block missing/ambiguous; matches={text.count(old_retention)}"
            )
        text = text.replace(old_retention, new_retention, 1)
    old_console = 'console.log("PASS: Phase 19 bounded settings snapshots, automatic pre-change backups and sidebar restore/delete contract");'
    new_console = 'console.log("PASS: Phase 19 bounded settings snapshots with manual/automatic retention classes, automatic pre-change backups and sidebar restore/delete contract");'
    if old_console in text:
        text = text.replace(old_console, new_console, 1)
    plan(rel, text)


def patch_sidebar_help() -> None:
    rel = "extension/sidebar/sidebar.html"
    text = read(rel)
    old = (
        "New snapshots cover all configuration. Retention keeps the newest 10 manual + 20 automatic "
        "recovery points; legacy pre-v0.40.9 snapshots remain supported."
    )
    new = (
        "New snapshots cover all configuration. Retention keeps the newest 10 manual + 20 automatic "
        "recovery points. Creating a manual snapshot promotes an identical automatic recovery point into "
        "the manual quota instead of duplicating it; legacy pre-v0.40.9 snapshots remain supported."
    )
    if new not in text:
        if text.count(old) != 1:
            raise PatchError(f"sidebar Phase 62 snapshot-help anchor expected once, found {text.count(old)}")
        text = text.replace(old, new, 1)
    plan(rel, text)


def create_or_verify(rel: str, content: str) -> None:
    path = ROOT / rel
    if path.exists():
        if read(rel) != content:
            raise PatchError(f"Existing generated file differs from Phase 63 target: {rel}")
        plan(rel, content)
    else:
        plan(rel, content)


def merge_metadata() -> None:
    rel = "CHANGELOG.md"
    text = read(rel)
    block = '''## [0.41.4] - 2026-08-07

### Fixed

- Creating a manual recovery snapshot now promotes an existing automatic snapshot with the same configuration fingerprint into the manual retention class instead of silently reusing the automatic recovery point.
- Duplicate automatic snapshots and duplicate manual snapshots remain deduplicated, and an automatic snapshot can never demote an existing manual recovery point.
- The historical Phase 19 snapshot test now follows the Phase 62 retention contract of 10 manual + 20 automatic snapshots instead of hard-coding the old total of 20.

### Compatibility

- Existing recovery data requires no migration.
- Protocol remains 26 and Native Host remains 0.13.0.

'''
    if "## [0.41.4] - 2026-08-07" not in text:
        anchors = ["## [0.41.3] - 2026-08-07", "## [0.41.2] - 2026-08-07"]
        matches = [anchor for anchor in anchors if anchor in text]
        if not matches:
            raise PatchError("CHANGELOG.md: Phase 62/61 anchor missing")
        text = text.replace(matches[0], block + matches[0], 1)
    plan(rel, text)

    rel = "PROJECT_STATUS.md"
    text = read(rel)
    text = re.sub(
        r"- Current add-on version: \*\*[0-9.]+\*\*",
        "- Current add-on version: **0.41.4**",
        text,
        count=1,
    )
    row = (
        "| Manual snapshot promotion | Manual creation promotes an identical automatic recovery point into the protected manual quota without duplicate configuration copies | **100%** | Completed in v0.41.4 |"
    )
    if row not in text:
        anchors = ["| Recovery snapshot retention |", "| Atomic full configuration commit |"]
        pos = next((text.find(anchor) for anchor in anchors if anchor in text), -1)
        if pos < 0:
            raise PatchError("PROJECT_STATUS.md: recent recovery row anchor missing")
        end = text.find("\n", pos)
        text = text[: end + 1] + row + "\n" + text[end + 1 :]
    plan(rel, text)

    rel = "document/CURRENT_PROJECT_STATUS.md"
    text = read(rel)
    text = re.sub(
        r"\*\*Current baseline:\*\* Phase [0-9]+ v[0-9.]+",
        "**Current baseline:** Phase 63 v0.41.4",
        text,
        count=1,
    )
    block = '''## Phase 63 v0.41.4 — Manual snapshot promotion

- A deliberate Manual snapshot now takes ownership of an identical automatic recovery point instead of being deduplicated away.
- Promotion keeps a single configuration copy, moves it into the protected manual quota and records the current Manual label/time/id.
- Automatic snapshots cannot demote an existing Manual snapshot.
- The historical Phase 19 capacity contract now matches Phase 62 retention (10 manual + 20 automatic).

'''
    if "## Phase 63 v0.41.4" not in text:
        anchors = ["## Phase 62 v0.41.3", "## Phase 61 v0.41.2"]
        matches = [anchor for anchor in anchors if anchor in text]
        if not matches:
            raise PatchError("CURRENT_PROJECT_STATUS.md: Phase 62/61 anchor missing")
        text = text.replace(matches[0], block + matches[0], 1)
    text = re.sub(r"Phase 04–[0-9]+ contracts", "Phase 04–63 contracts", text, count=1)
    plan(rel, text)

    rel = "document/PROJECT_IMPLEMENTATION_PLAN.md"
    text = read(rel)
    text = re.sub(
        r"> \*\*Current implementation baseline:\*\* Phase [0-9]+ v[0-9.]+",
        "> **Current implementation baseline:** Phase 63 v0.41.4",
        text,
        count=1,
    )
    if "## Phase 63 — Manual snapshot promotion" not in text:
        text = text.rstrip() + '''

## Phase 63 — Manual snapshot promotion

**Status:** Completed in v0.41.4.

- Preserve the user's deliberate Manual-snapshot intent when the same configuration already exists as an automatic safety snapshot.
- Promote instead of duplicating, preserving one fingerprint entry while moving it into the protected manual quota.
- Prevent later automatic snapshots from demoting an existing manual recovery point.
- Keep the historical Phase 19 regression aligned with the 10-manual + 20-automatic retention contract.
''' + "\n"
    plan(rel, text)

    rel = "README.md"
    text = read(rel)
    note = '''
### Manual snapshot promotion

If the current configuration already exists as an automatic safety snapshot, choosing **Create snapshot** still records the user's deliberate recovery intent: the matching automatic entry is promoted into the protected manual quota instead of creating a duplicate. Automatic snapshots never demote a manual recovery point.
'''
    if "### Manual snapshot promotion" not in text:
        anchors = ["### Recovery-history retention", "## Complete configuration backup and safe restore"]
        pos = next((text.find(anchor) for anchor in anchors if anchor in text), -1)
        if pos < 0:
            raise PatchError("README.md: recovery-history anchor missing")
        nxt = text.find("\n## ", pos + 3)
        text = text.rstrip() + note + "\n" if nxt < 0 else text[:nxt] + note + text[nxt:]
    plan(rel, text)

    rel = "tools/test_firefox_addon.sh"
    text = read(rel)
    line = "node tests/test_phase63_v0414_manual_snapshot_promotion.js"
    if line not in text:
        anchors = [
            "node tests/test_phase62_v0413_recovery_snapshot_retention_classes.js",
            "node tests/test_phase61_v0412_atomic_full_configuration_commit.js",
        ]
        matches = [anchor for anchor in anchors if anchor in text]
        if not matches:
            raise PatchError("test runner: Phase 62/61 anchor missing")
        text = text.replace(matches[0], matches[0] + "\n" + line, 1)
    desired = "PASS: FirefoxChatImprover Phase 04-63 v0.41.4 manual snapshot promotion, recovery snapshot retention, "
    if desired not in text:
        text = re.sub(
            r"PASS: FirefoxChatImprover Phase 04-[0-9]+ v[0-9.]+ (?:manual snapshot promotion, )?(?:recovery snapshot retention, )?",
            desired,
            text,
            count=1,
        )
    plan(rel, text)


def prepare() -> None:
    patch_manifest()
    patch_snapshots()
    patch_phase19_contract()
    patch_sidebar_help()
    create_or_verify(
        "tests/test_phase63_v0414_manual_snapshot_promotion.js",
        '''#!/usr/bin/env node
"use strict";
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const crypto = require("node:crypto");
const root = path.resolve(__dirname, "..");
const settingsSource = fs.readFileSync(path.join(root, "extension/shared/settings.js"), "utf8");
const snapshotsSource = fs.readFileSync(path.join(root, "extension/shared/settings_snapshots.js"), "utf8");
const manifest = JSON.parse(fs.readFileSync(path.join(root, "extension/manifest.json"), "utf8"));
const sandbox = { console, Date, JSON, Math, URL, Uint32Array, crypto: crypto.webcrypto, globalThis: null };
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(settingsSource, sandbox, { filename: "settings.js" });
vm.runInContext(snapshotsSource, sandbox, { filename: "settings_snapshots.js" });
const Settings = sandbox.FCI_SETTINGS;
const Snapshots = sandbox.FCI_SETTINGS_SNAPSHOTS;
assert(Snapshots.VERSION >= 4);
assert.equal(Snapshots.MAX_MANUAL_SNAPSHOTS, 10);
assert.equal(Snapshots.MAX_AUTOMATIC_SNAPSHOTS, 20);
const base = Settings.defaultStore();
const automatic = Snapshots.makeSnapshot(base, "before_profile_save", "Automatic", {
  id: "auto-same-state", createdAt: "2026-08-07T06:00:00.000Z"
});
let result = Snapshots.addSnapshot({}, automatic);
assert.equal(result.added, true);
assert.equal(result.collection.snapshots.length, 1);
assert.equal(Snapshots.snapshotRetentionClass(result.collection.snapshots[0]), "automatic");
const manual = Snapshots.makeSnapshot(base, "manual", "Manual checkpoint", {
  id: "manual-same-state", createdAt: "2026-08-07T06:01:00.000Z"
});
result = Snapshots.addSnapshot(result.collection, manual);
assert.equal(result.added, true, "manual intent must not be deduplicated away by an automatic snapshot");
assert.equal(result.promoted, true);
assert.equal(result.collection.snapshots.length, 1, "promotion must not duplicate identical configuration");
assert.equal(result.snapshot.id, "manual-same-state");
assert.equal(result.collection.snapshots[0].id, "manual-same-state");
assert.equal(result.collection.snapshots[0].reason, "manual");
assert.equal(Snapshots.snapshotRetentionClass(result.collection.snapshots[0]), "manual");
const autoAgain = Snapshots.makeSnapshot(base, "before_settings_import", "Automatic again", {
  id: "auto-after-manual", createdAt: "2026-08-07T06:02:00.000Z"
});
result = Snapshots.addSnapshot(result.collection, autoAgain);
assert.equal(result.added, false, "automatic duplicate must not demote an existing manual snapshot");
assert.equal(result.promoted, false);
assert.equal(result.collection.snapshots[0].id, "manual-same-state");
const manualAgain = Snapshots.makeSnapshot(base, "manual", "Manual duplicate", {
  id: "manual-duplicate", createdAt: "2026-08-07T06:03:00.000Z"
});
result = Snapshots.addSnapshot(result.collection, manualAgain);
assert.equal(result.added, false, "manual duplicate of an existing manual point stays deduplicated");
assert.equal(result.promoted, false);
assert.equal(result.collection.snapshots.length, 1);
const parts = manifest.version.split(".").map(Number);
assert(parts[0] > 0 || parts[1] > 41 || (parts[1] === 41 && parts[2] >= 4));
console.log("PASS: Phase 63 promotes matching automatic recovery points into the protected manual quota without duplicates or demotion");
''',
    )
    create_or_verify(
        "document/PHASE_63_V0_41_4_MANUAL_SNAPSHOT_PROMOTION.md",
        '''# Phase 63 v0.41.4 — Manual snapshot promotion

Phase 62 protected a dedicated manual recovery quota, but fingerprint deduplication could still discard a deliberate Manual snapshot when the same configuration already existed as an automatic safety snapshot. Phase 63 promotes that matching automatic entry into the manual retention class instead of creating a duplicate. The promoted entry receives the new Manual snapshot id, timestamp and label. Automatic duplicates can never demote it back to the automatic quota.
''',
    )
    merge_metadata()


def apply() -> list[str]:
    changed: list[str] = []
    for rel, target in planned.items():
        path = ROOT / rel
        current = path.read_text(encoding="utf-8") if path.is_file() else None
        if current == target:
            print(f"unchanged/check: {rel}")
            continue
        if path.is_file():
            backup_file(ROOT, rel, PATCH_NAME)
            print(f"patched: {rel}")
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            print(f"created: {rel}")
        path.write_text(target, encoding="utf-8")
        changed.append(rel)
    return changed


def run(cmd: list[str], label: str) -> None:
    print(f"CHECK: {label}")
    result = subprocess.run(cmd, cwd=ROOT)
    if result.returncode:
        raise PatchError(f"{label} failed with exit code {result.returncode}")


def validate(changed: list[str]) -> None:
    if not changed:
        print("CHECK: Phase 63 already applied; no commands run because no files changed.")
        return
    run(["node", "--check", "extension/shared/settings_snapshots.js"], "settings snapshot module syntax")
    run(["bash", "-n", "tools/test_firefox_addon.sh"], "test runner shell syntax")
    run(["node", "tests/test_phase63_v0414_manual_snapshot_promotion.js"], "Phase 63 manual-promotion contract")
    for test in [
        "tests/test_phase19_settings_snapshots.js",
        "tests/test_phase62_v0413_recovery_snapshot_retention_classes.js",
        "tests/test_phase58_v0409_complete_configuration_backup.js",
        "tests/test_phase61_v0412_atomic_full_configuration_commit.js",
    ]:
        if (ROOT / test).is_file():
            run(["node", test], Path(test).name)
    if (ROOT / "tests/test_phase42_v0393_release_status_consistency.py").is_file():
        run(["python3", "tests/test_phase42_v0393_release_status_consistency.py"], "Phase 42 release consistency")
    if (ROOT / "tools/check_source_syntax.py").is_file():
        run(["bash", "tools/test_firefox_addon.sh"], "Phase 04-63 full regression")
    else:
        print("SKIP: full regression unavailable in reconstructed source; complete repo will run it.")


try:
    prepare()
    changed = apply()
    validate(changed)
    print(f"[PASS] Phase 63 v0.41.4 manual snapshot promotion (changed={len(changed)})")
except Exception as exc:
    print(f"[FAIL] {type(exc).__name__}: {exc}", file=sys.stderr)
    raise SystemExit(1)
