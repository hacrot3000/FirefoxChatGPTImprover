# START HERE

Patch Tool: v5.16.0
Status: FAIL
Primary code: PTV-RUNNER-001
Primary issue: Stopping package after failed patch: patchs/patch_firefox_chat_improver_phase63_v0_41_4_manual_snapshot_promotion_v3_20260807_1415.zip::patch_firefox_chat_improver_phase63_v0_41_4_manual_snapshot_promotion_v3_20260807_1415.py
Location: <not detected>

Recommended action: Inspect the first structured diagnostic and important log before the final package error.

Read `AI_SUMMARY/failure_delta.md`, `AI_SUMMARY/root_causes.md`, `AI_SUMMARY/diagnostic_quality.md`, `AI_SUMMARY/security_redaction.json`, `AI_SUMMARY/environment_fingerprint.md`, `AI_SUMMARY/multi_machine_context.md`, and `NEXT_AI_ACTION.md`, then inspect only the matching files under `CODE_CONTEXT/`. Do not require patch-history continuity across machines. Return one corrected Patch Tool ZIP with the same project key, relative paths, and strict uniqueness checks.
