# NEXT AI ACTION

Primary diagnostic: `PTV-UNKNOWN-001`
Failure delta: `NO_PREVIOUS_FAILURE`
Action: Inspect the compact evidence and update only the affected patch/code.

## Files to inspect
1. Use the locations listed in `root_causes.md`.

## Constraints
- Return one ZIP patch using the standard manifest.
- Update the source baseline hashes when the corrected patch is generated against current code.
- Do not weaken exact-match or uniqueness checks merely to force the patch to pass.
- Do not modify unrelated files or project validation policy.
