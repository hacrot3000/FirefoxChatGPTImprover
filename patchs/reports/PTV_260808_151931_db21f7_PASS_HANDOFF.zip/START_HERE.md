# START HERE

Patch Tool: v5.16.0
Status: PASS
Primary code: PTV-UNKNOWN-001
Primary issue: No primary error detected
Location: <not detected>

Recommended action: Inspect the compact evidence and update only the affected patch/code.

Read `AI_SUMMARY/failure_delta.md`, `AI_SUMMARY/root_causes.md`, `AI_SUMMARY/diagnostic_quality.md`, `AI_SUMMARY/security_redaction.json`, `AI_SUMMARY/environment_fingerprint.md`, `AI_SUMMARY/multi_machine_context.md`, and `NEXT_AI_ACTION.md`, then inspect only the matching files under `CODE_CONTEXT/`. Do not require patch-history continuity across machines. Return one corrected Patch Tool ZIP with the same project key, relative paths, and strict uniqueness checks.
