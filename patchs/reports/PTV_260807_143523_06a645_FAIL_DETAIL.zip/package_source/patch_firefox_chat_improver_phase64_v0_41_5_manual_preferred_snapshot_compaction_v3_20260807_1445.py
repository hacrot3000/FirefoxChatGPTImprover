#!/usr/bin/env python3
"""Phase 64 v0.41.5: preserve Manual recovery intent during semantic history compaction."""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd().resolve()
PATCH_NAME = "phase64_v0_41_5_manual_preferred_snapshot_compaction"

sys.path.insert(0, str(ROOT / "tools"))
try:
    from python_patch_utils import backup_file
except Exception as exc:
    print(f"[FAIL] Cannot import patch helper: {exc}", file=sys.stderr)
    raise SystemExit(1)


class PatchError(RuntimeError):
    pass


planned: dict[str, str] = {}


def read(rel: str) -> str:
    path = ROOT / rel
    if not path.is_file():
        raise PatchError(f"Missing required file: {rel}")
    return planned.get(rel, path.read_text(encoding="utf-8"))


def plan(rel: str, text: str) -> None:
    planned[rel] = text


def version_tuple(value: str) -> tuple[int, ...]:
    try:
        return tuple(int(part) for part in str(value).split("."))
    except Exception:
        return (0, 0, 0)


def replace_function(text: str, signature: str, replacement: str, label: str) -> str:
    starts = [m.start() for m in re.finditer(re.escape(signature), text)]
    if len(starts) != 1:
        raise PatchError(f"{label}: expected exactly one {signature!r}, found {len(starts)}")
    start = starts[0]
    brace = text.find("{", start)
    if brace < 0:
        raise PatchError(f"{label}: opening brace not found")
    depth = 0
    quote = None
    escape = False
    i = brace
    while i < len(text):
        ch = text[i]
        if quote is not None:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == quote:
                quote = None
        else:
            if ch in ('"', "'", "`"):
                quote = ch
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return text[:start] + replacement + text[i + 1:]
        i += 1
    raise PatchError(f"{label}: closing brace not found")


def patch_manifest() -> None:
    rel = "extension/manifest.json"
    data = json.loads(read(rel))
    current = version_tuple(data.get("version", "0.0.0"))
    if current < (0, 41, 4):
        raise PatchError(
            f"Phase 64 requires corrected Phase 63 v0.41.4 or newer; found {data.get('version')}"
        )
    if current < (0, 41, 5):
        data["version"] = "0.41.5"
    plan(rel, json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def patch_snapshots() -> None:
    rel = "extension/shared/settings_snapshots.js"
    text = read(rel)
    required = [
        'const ConfigurationBundle = globalThis.FCI_CONFIGURATION_BUNDLE || null;',
        'const MAX_SNAPSHOTS = 20;',
        'function normalizeCollection(raw)',
        'function addSnapshot(rawCollection, rawSnapshot)',
        'const shouldPromoteManual = snapshot.reason === "manual" && existing.reason !== "manual";',
    ]
    missing = [marker for marker in required if marker not in text]
    if missing:
        raise PatchError(
            "settings_snapshots.js: Phase 63 semantic/manual-promotion baseline markers missing: "
            + ", ".join(missing)
        )

    target_marker = 'const byFingerprint = new Map();'
    if target_marker not in text or 'existing.reason !== "manual" && snapshot.reason === "manual"' not in text:
        start = text.find("function normalizeCollection(raw)")
        end = text.find("\n  function ", start + 1)
        if start < 0 or end < 0:
            raise PatchError("settings_snapshots.js: normalizeCollection structural boundary not found")
        current_fn = text[start:end]
        baseline_markers = [
            "const source = raw && typeof raw === \"object\" ? raw : {};",
            "const snapshots = [];",
            "normalizeSnapshot(candidate, index)",
            "snapshots.sort(",
            "MAX_SNAPSHOTS",
        ]
        missing_fn = [marker for marker in baseline_markers if marker not in current_fn]
        if missing_fn:
            raise PatchError(
                "settings_snapshots.js: normalizeCollection does not match the bounded semantic baseline: "
                + ", ".join(missing_fn)
            )

        replacement = '''function normalizeCollection(raw) {
    const source = raw && typeof raw === "object" ? raw : {};
    const seenIds = new Set();
    const snapshots = [];
    for (const [index, candidate] of (Array.isArray(source.snapshots) ? source.snapshots : []).entries()) {
      const snapshot = normalizeSnapshot(candidate, index);
      if (seenIds.has(snapshot.id)) {
        continue;
      }
      seenIds.add(snapshot.id);
      snapshots.push(snapshot);
    }
    snapshots.sort((left, right) => right.createdAt.localeCompare(left.createdAt));

    // Phase 64: semantic duplicates are compacted with explicit Manual intent
    // taking precedence over automatic safety snapshots. Within the same class,
    // the first entry is already the newest because snapshots were sorted above.
    const byFingerprint = new Map();
    for (const snapshot of snapshots) {
      const existing = byFingerprint.get(snapshot.fingerprint);
      if (!existing) {
        byFingerprint.set(snapshot.fingerprint, snapshot);
        continue;
      }
      if (existing.reason !== "manual" && snapshot.reason === "manual") {
        byFingerprint.set(snapshot.fingerprint, snapshot);
      }
    }
    const compacted = Array.from(byFingerprint.values());
    compacted.sort((left, right) => right.createdAt.localeCompare(left.createdAt));
    return {
      version: VERSION,
      snapshots: compacted.slice(0, MAX_SNAPSHOTS)
    };
  }'''
        text = replace_function(
            text,
            "function normalizeCollection(raw)",
            replacement,
            "settings snapshot normalizeCollection",
        )

    guard = re.search(r"if \(globalThis\.FCI_SETTINGS_SNAPSHOTS\?\.VERSION >= (\d+)\)", text)
    version = re.search(r"const VERSION = (\d+);", text)
    if not guard or not version:
        raise PatchError("settings_snapshots.js: module guard/VERSION missing")
    if int(guard.group(1)) < 5:
        text = text[: guard.start(1)] + "5" + text[guard.end(1):]
    version = re.search(r"const VERSION = (\d+);", text)
    if int(version.group(1)) < 5:
        text = text[: version.start(1)] + "5" + text[version.end(1):]

    final_markers = [
        "const byFingerprint = new Map();",
        "const existing = byFingerprint.get(snapshot.fingerprint);",
        'if (existing.reason !== "manual" && snapshot.reason === "manual")',
        "const compacted = Array.from(byFingerprint.values());",
        "snapshots: compacted.slice(0, MAX_SNAPSHOTS)",
    ]
    missing = [marker for marker in final_markers if marker not in text]
    if missing:
        raise PatchError("settings_snapshots.js: Phase 64 compaction markers missing: " + ", ".join(missing))
    plan(rel, text)


def create_or_verify(rel: str, content: str) -> None:
    path = ROOT / rel
    if path.exists():
        current = read(rel)
        if current != content:
            raise PatchError(f"Existing generated file differs from Phase 64 target: {rel}")
        plan(rel, content)
    else:
        plan(rel, content)


def patch_metadata() -> None:
    rel = "CHANGELOG.md"
    text = read(rel)
    block = '''## [0.41.5] - 2026-08-07

### Fixed

- Recovery-history normalization now preserves a Manual recovery point when an older Manual and newer automatic snapshot represent the same semantic configuration.
- Existing duplicate semantic snapshots are compacted with Manual-over-automatic priority; among snapshots of the same class, the newest entry is retained.

### Compatibility

- Phase 62 semantic fingerprints, Phase 63 add-time Manual promotion and the bounded `MAX_SNAPSHOTS = 20` policy remain unchanged.
- Protocol remains 26 and Native Host remains 0.13.0.

'''
    if "## [0.41.5] - 2026-08-07" not in text:
        anchors = ["## [0.41.4] - 2026-08-07", "## [0.41.3] - 2026-08-07"]
        selected = next((a for a in anchors if a in text), None)
        if selected is None or text.count(selected) != 1:
            raise PatchError("CHANGELOG.md: Phase 63/62 anchor missing or ambiguous")
        text = text.replace(selected, block + selected, 1)
    plan(rel, text)

    rel = "PROJECT_STATUS.md"
    text = read(rel)
    text = re.sub(
        r"- Current add-on version: \*\*[0-9.]+\*\*",
        "- Current add-on version: **0.41.5**",
        text,
        count=1,
    )
    row = "| Manual-preferred snapshot compaction | Recovery-history normalization preserves Manual intent over newer automatic duplicates while retaining the newest entry within the same snapshot class | **100%** | Completed in v0.41.5 |"
    if row not in text:
        anchor = "| Manual snapshot promotion |"
        if anchor not in text:
            anchor = "| Semantic recovery-snapshot deduplication |"
        if text.count(anchor) != 1:
            raise PatchError(f"PROJECT_STATUS.md: snapshot anchor expected once, found {text.count(anchor)}")
        pos = text.index(anchor)
        end = text.find("\n", pos)
        text = text[: end + 1] + row + "\n" + text[end + 1:]
    plan(rel, text)

    rel = "document/CURRENT_PROJECT_STATUS.md"
    text = read(rel)
    text = re.sub(
        r"\*\*Current baseline:\*\* Phase [0-9]+ v[0-9.]+",
        "**Current baseline:** Phase 64 v0.41.5",
        text,
        count=1,
    )
    block = '''## Phase 64 v0.41.5 — Manual-preferred snapshot compaction

- Recovery-history normalization now uses the same Manual-over-automatic intent rule as Phase 63 add-time deduplication.
- A newer automatic snapshot can no longer erase an older Manual recovery point with the same semantic fingerprint during browser/background reload.
- When duplicates have the same class, the newest snapshot is retained.
- Semantic fingerprint rules and the bounded 20-snapshot retention policy remain unchanged.

'''
    if "## Phase 64 v0.41.5" not in text:
        anchors = ["## Phase 63 v0.41.4", "## Phase 62 v0.41.3"]
        selected = next((a for a in anchors if a in text), None)
        if selected is None or text.count(selected) != 1:
            raise PatchError("CURRENT_PROJECT_STATUS.md: Phase 63/62 anchor missing or ambiguous")
        text = text.replace(selected, block + selected, 1)
    text = re.sub(r"Phase 04–[0-9]+ contracts", "Phase 04–64 contracts", text, count=1)
    plan(rel, text)

    rel = "document/PROJECT_IMPLEMENTATION_PLAN.md"
    text = read(rel)
    text = re.sub(
        r"> \*\*Current implementation baseline:\*\* Phase [0-9]+ v[0-9.]+",
        "> **Current implementation baseline:** Phase 64 v0.41.5",
        text,
        count=1,
    )
    if "## Phase 64 — Manual-preferred snapshot compaction" not in text:
        text = text.rstrip() + '''

## Phase 64 — Manual-preferred snapshot compaction

**Status:** Completed in v0.41.5.

- Apply Manual-over-automatic precedence while compacting stored semantic snapshot duplicates during collection normalization.
- Keep the newest duplicate within the same Manual/automatic class.
- Preserve Phase 62 semantic fingerprint identity, Phase 63 add-time promotion and the existing 20-snapshot retention bound.
''' + "\n"
    plan(rel, text)

    rel = "README.md"
    text = read(rel)
    note = '''
### Manual recovery points survive history compaction

Recovery history applies the same Manual intent rule both when a snapshot is created and when stored history is normalized after reload. If an older Manual snapshot and a newer automatic safety snapshot have the same semantic fingerprint, the Manual recovery point is retained; among duplicates of the same class, the newest is kept. This prevents browser/background reload from undoing the Manual protection introduced by Phase 63.
'''
    if "### Manual recovery points survive history compaction" not in text:
        anchors = ["### Manual snapshot promotion", "## Complete configuration backup and safe restore"]
        selected = next((a for a in anchors if a in text), None)
        if selected is None or text.count(selected) != 1:
            raise PatchError("README.md: snapshot recovery anchor missing or ambiguous")
        pos = text.index(selected)
        nxt = text.find("\n## ", pos + len(selected))
        text = text.rstrip() + note + "\n" if nxt < 0 else text[:nxt] + note + text[nxt:]
    plan(rel, text)

    rel = "tools/test_firefox_addon.sh"
    text = read(rel)
    line = "node tests/test_phase64_v0415_manual_preferred_snapshot_compaction.js"
    if line not in text:
        anchors = [
            "node tests/test_phase63_v0414_manual_snapshot_promotion.js",
            "node tests/test_phase62_v0413_semantic_recovery_snapshot_deduplication.js",
        ]
        selected = next((a for a in anchors if a in text), None)
        if selected is None or text.count(selected) != 1:
            raise PatchError("test runner: Phase 63/62 snapshot anchor missing or ambiguous")
        text = text.replace(selected, selected + "\n" + line, 1)
    if "PASS: FirefoxChatImprover Phase 04-64 v0.41.5 manual-preferred snapshot compaction," not in text:
        match = re.search(r"PASS: FirefoxChatImprover Phase 04-[0-9]+ v[0-9.]+ ", text)
        if not match:
            raise PatchError("test runner: final PASS summary prefix not found")
        text = (
            text[: match.start()]
            + "PASS: FirefoxChatImprover Phase 04-64 v0.41.5 manual-preferred snapshot compaction, "
            + text[match.end():]
        )
    plan(rel, text)


def prepare() -> None:
    patch_manifest()
    patch_snapshots()
    create_or_verify(
        "tests/test_phase64_v0415_manual_preferred_snapshot_compaction.js",
        '''#!/usr/bin/env node
"use strict";
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const crypto = require("node:crypto");
const root = path.resolve(__dirname, "..");
const settingsSource = fs.readFileSync(path.join(root, "extension/shared/settings.js"), "utf8");
const snapshotsSource = fs.readFileSync(path.join(root, "extension/shared/settings_snapshots.js"), "utf8");
const manifest = JSON.parse(fs.readFileSync(path.join(root, "extension/manifest.json"), "utf8"));
const sandbox = { console, Date, JSON, Math, URL, Uint32Array, crypto: crypto.webcrypto, globalThis: null };
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(settingsSource, sandbox, { filename: "settings.js" });
vm.runInContext(snapshotsSource, sandbox, { filename: "settings_snapshots.js" });
const Settings = sandbox.FCI_SETTINGS;
const Snapshots = sandbox.FCI_SETTINGS_SNAPSHOTS;
assert(Snapshots.VERSION >= 5);
assert.equal(Snapshots.MAX_SNAPSHOTS, 20);
const base = Settings.defaultStore();
const same = (reason, id, createdAt) => Snapshots.makeSnapshot(base, reason, id, { id, createdAt });

let normalized = Snapshots.normalizeCollection({ snapshots: [
  same("manual", "manual-old", "2026-08-07T06:00:00.000Z"),
  same("before_profile_save", "auto-new", "2026-08-07T06:01:00.000Z")
] });
assert.equal(normalized.snapshots.length, 1);
assert.equal(normalized.snapshots[0].id, "manual-old", "Manual must survive a newer automatic semantic duplicate during collection load");
assert.equal(normalized.snapshots[0].reason, "manual");

normalized = Snapshots.normalizeCollection({ snapshots: [
  same("before_profile_save", "auto-old", "2026-08-07T06:00:00.000Z"),
  same("manual", "manual-new", "2026-08-07T06:01:00.000Z")
] });
assert.equal(normalized.snapshots[0].id, "manual-new");

normalized = Snapshots.normalizeCollection({ snapshots: [
  same("before_profile_save", "auto-old-2", "2026-08-07T06:00:00.000Z"),
  same("before_settings_import", "auto-new-2", "2026-08-07T06:02:00.000Z")
] });
assert.equal(normalized.snapshots.length, 1);
assert.equal(normalized.snapshots[0].id, "auto-new-2", "Newest automatic duplicate must win within automatic class");

normalized = Snapshots.normalizeCollection({ snapshots: [
  same("manual", "manual-old-2", "2026-08-07T06:00:00.000Z"),
  same("manual", "manual-new-2", "2026-08-07T06:03:00.000Z")
] });
assert.equal(normalized.snapshots.length, 1);
assert.equal(normalized.snapshots[0].id, "manual-new-2", "Newest Manual duplicate must win within Manual class");

let result = Snapshots.addSnapshot(normalized, same("before_profile_delete", "auto-after-manual", "2026-08-07T06:04:00.000Z"));
assert.equal(result.added, false, "Phase 63 must still prevent automatic demotion after Phase 64 normalization");
assert.equal(result.collection.snapshots[0].reason, "manual");

const parts = manifest.version.split(".").map(Number);
assert(parts[0] > 0 || parts[1] > 41 || (parts[1] === 41 && parts[2] >= 5));
console.log("PASS: Phase 64 preserves Manual recovery intent during semantic collection compaction and keeps newest duplicates within each class");
''',
    )
    patch_metadata()


def apply() -> list[str]:
    changed: list[str] = []
    for rel, target in planned.items():
        path = ROOT / rel
        current = path.read_text(encoding="utf-8") if path.is_file() else None
        if current == target:
            print(f"unchanged/check: {rel}")
            continue
        if path.is_file():
            backup_file(ROOT, rel, PATCH_NAME)
            print(f"patched: {rel}")
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            print(f"created: {rel}")
        path.write_text(target, encoding="utf-8")
        changed.append(rel)
    return changed


def run(cmd: list[str], label: str) -> None:
    print(f"CHECK: {label}")
    result = subprocess.run(cmd, cwd=ROOT)
    if result.returncode:
        raise PatchError(f"{label} failed with exit code {result.returncode}")


def validate(changed: list[str]) -> None:
    if not changed:
        print("CHECK: Phase 64 already applied; no commands run because no files changed.")
        return
    run(["node", "--check", "extension/shared/settings_snapshots.js"], "settings snapshot JavaScript syntax")
    run(["bash", "-n", "tools/test_firefox_addon.sh"], "test runner shell syntax")
    for test in [
        "tests/test_phase19_settings_snapshots.js",
        "tests/test_phase63_v0414_manual_snapshot_promotion.js",
        "tests/test_phase64_v0415_manual_preferred_snapshot_compaction.js",
    ]:
        if (ROOT / test).is_file():
            run(["node", test], Path(test).name)
    if (ROOT / "tests/test_phase62_v0413_semantic_recovery_snapshot_deduplication.js").is_file():
        run(
            ["node", "tests/test_phase62_v0413_semantic_recovery_snapshot_deduplication.js"],
            "Phase 62 semantic recovery snapshot regression",
        )
    if (ROOT / "tools/check_source_syntax.py").is_file():
        run(["bash", "tools/test_firefox_addon.sh"], "Phase 04-64 full regression")
    else:
        print("SKIP: full regression unavailable in reconstructed source; complete repo will run it.")


try:
    prepare()
    changed = apply()
    validate(changed)
    print(f"[PASS] Phase 64 v0.41.5 manual-preferred snapshot compaction (changed={len(changed)})")
except Exception as exc:
    print(f"[FAIL] {type(exc).__name__}: {exc}", file=sys.stderr)
    raise SystemExit(1)
