# Source drift analysis

Status: **NOT_PROVIDED**
Checked: 0
Drifted: 0

No `source_baseline.files` entries were supplied by the patch manifest.
