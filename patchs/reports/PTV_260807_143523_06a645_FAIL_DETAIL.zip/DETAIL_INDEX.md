# Detail bundle

The separate DETAIL ZIP contains complete raw command logs, runner logs, Git evidence, and machine-readable results. Send it only when compact evidence is insufficient.
