# Diagnostics

## 1. ERROR — package

- Location: `<not detected>`
- Message: Stopping package after failed patch: patchs/patch_firefox_chat_improver_phase64_v0_41_5_manual_preferred_snapshot_compaction_v3_20260807_1445.zip::patch_firefox_chat_improver_phase64_v0_41_5_manual_preferred_snapshot_compaction_v3_20260807_1445.py
- Suggested next check: Inspect the first structured diagnostic and important log before the final package error.
- Source: `runner`

```text
Stopping package after failed patch: patchs/patch_firefox_chat_improver_phase64_v0_41_5_manual_preferred_snapshot_compaction_v3_20260807_1445.zip::patch_firefox_chat_improver_phase64_v0_41_5_manual_preferred_snapshot_compaction_v3_20260807_1445.py
```
