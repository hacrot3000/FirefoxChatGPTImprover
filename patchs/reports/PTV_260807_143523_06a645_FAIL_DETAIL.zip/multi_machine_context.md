# Multi-machine patch context

- Project key: ``
- Identity/history scope: **local machine only**
- Patch history continuity required: **NO**
- Missing history is an error: **NO**
- Source of truth: **current Git/source and patch preconditions**
- Paths: **project-relative preferred**

AI must not request patch history from another machine, infer missing phases from local history, or reject a patch solely because history is incomplete. Preserve the same `project.key`.
