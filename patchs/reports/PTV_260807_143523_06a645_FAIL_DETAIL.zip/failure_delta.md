# Failure delta

Status: **FIRST_FAILURE**
Patch key: `patch_firefox_chat_improver_phase64_v0_41_5_manual_preferred_snapshot_compaction_v3_20260807_1445`
Current run: **FAIL** (`APPLY`)
Previous failure: `none`

New causes: 1
Resolved causes: 0
Retained causes: 0

## New root causes

- `PTV-RUNNER-001` at `<unknown>` — Stopping package after failed patch: patchs/patch_firefox_chat_improver_phase64_v0_41_5_manual_preferred_snapshot_compaction_v3_20260807_1445.zip::patch_firefox_chat_improver_phase64_v0_41_5_manual_preferred_snapshot_compaction_v3_20260807_1445.py
