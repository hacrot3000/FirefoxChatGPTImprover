# Failure delta

Status: **FIRST_FAILURE**
Patch key: `patch_firefox_chat_improver_phase60_v0_41_1_configuration_import_preview_confirmation_v3_20260807_1245`
Current run: **FAIL** (`APPLY`)
Previous failure: `none`

New causes: 1
Resolved causes: 0
Retained causes: 0

## New root causes

- `PTV-ANCHOR-001` at `<unknown>` — [FAIL] PatchError: extension/manifest.json: expected v0.41.0 or v0.41.1, found 0.41.3
