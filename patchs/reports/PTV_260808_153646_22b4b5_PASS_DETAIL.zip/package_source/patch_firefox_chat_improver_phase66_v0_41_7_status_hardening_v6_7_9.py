#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, sys, tempfile
from pathlib import Path

PATCH_NAME = "FirefoxChatImprover Phase 66 v0.41.7 Phase 65 status hardening"
HERE = Path(__file__).resolve().parent
RESOURCE_ROOT = HERE / "resources"
BASELINE = json.loads((HERE / "PATCH_BASELINE.json").read_text(encoding="utf-8"))
ROOT = Path.cwd().resolve()


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_target(rel: str) -> Path:
    p = (ROOT / rel).resolve()
    try:
        p.relative_to(ROOT)
    except ValueError:
        raise RuntimeError(f"unsafe path outside project root: {rel}")
    return p


def main() -> int:
    manifest = ROOT / "extension" / "manifest.json"
    if not manifest.is_file():
        raise RuntimeError("FirefoxChatImprover extension/manifest.json not found in current project root")
    try:
        ext = json.loads(manifest.read_text(encoding="utf-8"))
    except Exception as exc:
        raise RuntimeError(f"cannot read extension manifest: {exc}") from exc
    if ext.get("name") != "Firefox ChatAI Assistant":
        raise RuntimeError(f"unexpected project manifest name: {ext.get('name')!r}")

    pending = []
    unchanged = []
    drift = []
    for item in BASELINE["files"]:
        rel = item["path"]
        target = safe_target(rel)
        resource = RESOURCE_ROOT / rel
        expected_new = item["new_sha256"]
        if not resource.is_file() or digest(resource) != expected_new:
            raise RuntimeError(f"patch resource checksum mismatch: {rel}")

        if target.exists():
            if not target.is_file():
                drift.append(f"{rel}: target is not a regular file")
                continue
            current = digest(target)
            if current == expected_new:
                unchanged.append(rel)
            elif current in set(item.get("accepted_old_sha256") or []):
                pending.append((rel, target, resource, False))
            else:
                accepted = ", ".join(item.get("accepted_old_sha256") or []) or "<none>"
                drift.append(f"{rel}: current sha256={current}; accepted old={accepted}; new={expected_new}")
        elif item.get("allow_missing"):
            pending.append((rel, target, resource, True))
        else:
            drift.append(f"{rel}: file missing and this baseline requires an existing file")

    if drift:
        print("[FAIL] Source baseline mismatch; no files were changed.", file=sys.stderr)
        for row in drift:
            print(f"  - {row}", file=sys.stderr)
        return 2

    if not pending:
        print(f"PASS: {PATCH_NAME}")
        print(f"already applied: {len(unchanged)} files")
        print("PHASE UNDER TEST: Phase 66")
        return 0

    new_hash = {item["path"]: item["new_sha256"] for item in BASELINE["files"]}
    for rel, target, resource, created in pending:
        target.parent.mkdir(parents=True, exist_ok=True)
        mode = target.stat().st_mode & 0o7777 if target.exists() else None
        data = resource.read_bytes()
        fd, tmp_name = tempfile.mkstemp(prefix=f".{target.name}.ptv66.", dir=str(target.parent))
        tmp = Path(tmp_name)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            if mode is not None:
                os.chmod(tmp, mode)
            os.replace(tmp, target)
        finally:
            if tmp.exists():
                tmp.unlink()
        if digest(target) != new_hash[rel]:
            raise RuntimeError(f"post-write checksum mismatch: {rel}")
        print(("created" if created else "patched") + f": {rel}")

    print(f"PASS: {PATCH_NAME}")
    print(f"changed={len(pending)} unchanged={len(unchanged)} total={len(BASELINE['files'])}")
    print("PHASE UNDER TEST: Phase 66")
    print("Regression scope: Phase 65 compact RD + managed-download header lifecycle; timer-driven capture expiry; alert-engine reattachment version guard. No new feature group.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"[FAIL] {PATCH_NAME}: {exc}", file=sys.stderr)
        raise SystemExit(1)
