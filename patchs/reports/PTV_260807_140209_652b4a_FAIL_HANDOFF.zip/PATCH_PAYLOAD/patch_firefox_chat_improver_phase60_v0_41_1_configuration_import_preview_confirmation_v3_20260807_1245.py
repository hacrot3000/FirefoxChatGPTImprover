#!/usr/bin/env python3
from __future__ import annotations
import json, re, subprocess, sys
from pathlib import Path

ROOT = Path.cwd().resolve()
PATCH_NAME = "phase60_v0_41_1_configuration_import_preview_confirmation"
sys.path.insert(0, str(ROOT / "tools"))
try:
    from python_patch_utils import backup_file
except Exception as exc:
    print(f"[FAIL] Cannot import patch helper: {exc}", file=sys.stderr)
    raise SystemExit(1)

class PatchError(RuntimeError):
    pass

planned: dict[str, str] = {}

def read(rel: str) -> str:
    p = ROOT / rel
    if not p.is_file():
        raise PatchError(f"Missing required file: {rel}")
    return p.read_text(encoding="utf-8")

def plan(rel: str, text: str) -> None:
    planned[rel] = text

def replace_once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        return text
    count = text.count(old)
    if count != 1:
        raise PatchError(f"{label}: expected baseline block once, found {count}")
    return text.replace(old, new, 1)

def ensure_created(rel: str, target: str) -> None:
    p = ROOT / rel
    if p.exists():
        current = read(rel)
        if current != target:
            raise PatchError(f"{rel} already exists with unexpected content")
        plan(rel, current)
    else:
        plan(rel, target)

PREVIEW_FUNCTION = '''  async function previewSettingsImport(text) {
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch (error) {
      throw new Error(`The selected configuration file is not valid JSON: ${error instanceof Error ? error.message : String(error)}`);
    }

    if (parsed && typeof parsed === "object" && Object.prototype.hasOwnProperty.call(parsed, "format")) {
      if (!ConfigurationBundle.isBundle(parsed)) {
        throw new Error("The selected file uses an unsupported Firefox ChatAI Assistant configuration-bundle format or version.");
      }
      const bundle = ConfigurationBundle.normalizeBundle(parsed);
      return {
        scope: "all-configuration",
        automationProfiles: bundle.automationStore.profiles.length,
        monitorProfiles: bundle.automationStore.monitorProfiles.length,
        targetProfiles: bundle.automationStore.targetProfiles.length,
        localActionProfiles: bundle.localActionStore.profiles.length,
        commandPresets: bundle.commandPresetStore.presets.length,
        customPromptTemplates: bundle.promptTemplateStore.customTemplates.length,
        sidebarFeaturePreset: bundle.sidebarPreferences.featurePreset,
        visibleSidebarFeatures: bundle.sidebarPreferences.visibleFeatures.length
      };
    }

    const store = Settings.normalizeStore(parsed);
    return {
      scope: "legacy-automation-only",
      automationProfiles: store.profiles.length,
      monitorProfiles: store.monitorProfiles.length,
      targetProfiles: store.targetProfiles.length,
      localActionProfiles: null,
      commandPresets: null,
      customPromptTemplates: null,
      sidebarFeaturePreset: null,
      visibleSidebarFeatures: null
    };
  }

'''

OLD_IMPORT_UI = '''  elements.importFile.addEventListener("change", async () => {
    const file = elements.importFile.files?.[0];
    if (!file) return;
    const text = await file.text();
    const response = await request(MESSAGE.IMPORT_SETTINGS, { text }, "", { reloadForm: true });
    elements.importFile.value = "";
    if (!response?.ok) return;
    if (response.scope === "all-configuration") {
      const automationPreserved = Number(response.automationPreservation?.preservedActiveTabs || 0) + Number(response.automationPreservation?.preservedStoppedTabs || 0);
      const localActionPreserved = Number(response.localActionPreservation?.preservedActiveTabs || 0) + Number(response.localActionPreservation?.preservedStoppedTabs || 0);
      const preservedDetail = automationPreserved || localActionPreserved
        ? ` Preserved tab overrides: ${automationPreserved} Automation, ${localActionPreserved} Local action.`
        : "";
      showMessage(`Full configuration imported. Existing open/stopped tabs kept their current Automation and Local action values where imported profiles differed.${preservedDetail} Reloading the sidebar to apply imported UI, preset and template preferences…`, "success");
      window.setTimeout(() => window.location.reload(), 180);
    } else {
      showMessage("Legacy Automation-only configuration imported. Local action profiles, presets, templates and sidebar preferences were left unchanged.", "success");
    }
  });
'''

NEW_IMPORT_UI = '''  elements.importFile.addEventListener("change", async () => {
    const file = elements.importFile.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const previewResponse = await request(MESSAGE.PREVIEW_SETTINGS_IMPORT, { text }, "", { reloadForm: false });
      const preview = previewResponse?.preview;
      if (!previewResponse?.ok || !preview) return;
      const details = preview.scope === "all-configuration"
        ? [
            `${preview.automationProfiles} Automation`,
            `${preview.monitorProfiles} Monitor`,
            `${preview.targetProfiles} Target`,
            `${preview.localActionProfiles} Local action`,
            `${preview.commandPresets} command preset(s)`,
            `${preview.customPromptTemplates} custom prompt template(s)`,
            `sidebar preset: ${preview.sidebarFeaturePreset || "standard"}`
          ].join(", ")
        : `${preview.automationProfiles} Automation, ${preview.monitorProfiles} Monitor, ${preview.targetProfiles} Target profile(s)`;
      const scopeText = preview.scope === "all-configuration"
        ? "FULL configuration bundle"
        : "LEGACY Automation-only configuration";
      const warning = preview.scope === "all-configuration"
        ? "This replaces the global Automation, Local action, preset, template and sidebar-preference libraries. Open/stopped tabs keep their current effective values where profiles differ."
        : "This replaces only the global Automation library. Local action profiles, presets, templates and sidebar preferences stay unchanged.";
      if (!confirm(`Import ${scopeText}?\n\nFile: ${file.name}\nContains: ${details}\n\n${warning}\n\nA recovery snapshot will be created before import.`)) return;
      const response = await request(MESSAGE.IMPORT_SETTINGS, { text }, "", { reloadForm: true });
      if (!response?.ok) return;
      if (response.scope === "all-configuration") {
        const automationPreserved = Number(response.automationPreservation?.preservedActiveTabs || 0) + Number(response.automationPreservation?.preservedStoppedTabs || 0);
        const localActionPreserved = Number(response.localActionPreservation?.preservedActiveTabs || 0) + Number(response.localActionPreservation?.preservedStoppedTabs || 0);
        const preservedDetail = automationPreserved || localActionPreserved
          ? ` Preserved tab overrides: ${automationPreserved} Automation, ${localActionPreserved} Local action.`
          : "";
        showMessage(`Full configuration imported. Existing open/stopped tabs kept their current Automation and Local action values where imported profiles differed.${preservedDetail} Reloading the sidebar to apply imported UI, preset and template preferences…`, "success");
        window.setTimeout(() => window.location.reload(), 180);
      } else {
        showMessage("Legacy Automation-only configuration imported. Local action profiles, presets, templates and sidebar preferences were left unchanged.", "success");
      }
    } finally {
      elements.importFile.value = "";
    }
  });
'''

TEST_CONTENT = '''#!/usr/bin/env node
"use strict";
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const root = path.resolve(__dirname, "..");
const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");
const manifest = JSON.parse(read("extension/manifest.json"));
const protocol = read("extension/shared/protocol.js");
const background = read("extension/background/background.js");
const sidebar = read("extension/sidebar/sidebar.js");
function versionAtLeast(actual, minimum) {
  const a = String(actual).split(".").map(Number), b = String(minimum).split(".").map(Number);
  for (let i = 0; i < Math.max(a.length, b.length); i += 1) {
    const av = a[i] || 0, bv = b[i] || 0;
    if (av !== bv) return av > bv;
  }
  return true;
}
assert(versionAtLeast(manifest.version, "0.41.1"));
assert(protocol.includes('PREVIEW_SETTINGS_IMPORT: "FCI_PREVIEW_SETTINGS_IMPORT"'));
assert(background.includes("async function previewSettingsImport(text)"));
assert(background.includes("automationProfiles: bundle.automationStore.profiles.length"));
assert(background.includes("localActionProfiles: bundle.localActionStore.profiles.length"));
assert(background.includes("commandPresets: bundle.commandPresetStore.presets.length"));
assert(background.includes("customPromptTemplates: bundle.promptTemplateStore.customTemplates.length"));
assert(background.includes("case MESSAGE.PREVIEW_SETTINGS_IMPORT:"));
assert(sidebar.includes("MESSAGE.PREVIEW_SETTINGS_IMPORT, MESSAGE.IMPORT_SETTINGS"));
assert(sidebar.includes("A recovery snapshot will be created before import."));
const previewIndex = sidebar.indexOf("const previewResponse = await request(MESSAGE.PREVIEW_SETTINGS_IMPORT");
const confirmIndex = sidebar.indexOf("if (!confirm(`Import ${scopeText}?", previewIndex);
const importIndex = sidebar.indexOf("const response = await request(MESSAGE.IMPORT_SETTINGS", previewIndex);
assert(previewIndex >= 0 && confirmIndex > previewIndex && importIndex > confirmIndex, "preview and confirmation must happen before the mutating import request");
console.log("PASS: Phase 60 configuration import validates and previews scope/counts before explicit confirmation and mutation");
'''

DOC_CONTENT = '''# Phase 60 v0.41.1 — Configuration import preview and confirmation

Configuration import is now a two-step operation. Selecting a file first performs a read-only parse/validation and returns the scope plus profile/preset/template counts. No storage is modified during preview. The sidebar then asks for explicit confirmation before issuing the mutating import request.

Full bundles identify Automation, Monitor, Target, Local action, command preset, custom prompt-template and sidebar-preset contents. Legacy files are identified as Automation-only. Both paths retain the existing automatic recovery snapshot immediately before mutation.
'''

def prepare() -> None:
    rel = "extension/manifest.json"
    data = json.loads(read(rel))
    version = str(data.get("version") or "")
    if version not in {"0.41.0", "0.41.1"}:
        raise PatchError(f"{rel}: expected v0.41.0 or v0.41.1, found {version}")
    data["version"] = "0.41.1"
    plan(rel, json.dumps(data, indent=2, ensure_ascii=False) + "\n")

    rel = "extension/shared/protocol.js"
    text = read(rel)
    text = replace_once(
        text,
        '      IMPORT_SETTINGS: "FCI_IMPORT_SETTINGS",\n',
        '      PREVIEW_SETTINGS_IMPORT: "FCI_PREVIEW_SETTINGS_IMPORT",\n      IMPORT_SETTINGS: "FCI_IMPORT_SETTINGS",\n',
        "protocol preview message"
    )
    plan(rel, text)

    rel = "extension/background/background.js"
    text = read(rel)
    if "async function previewSettingsImport(text)" not in text:
        anchor = "  async function importSettings(text) {\n"
        if text.count(anchor) != 1:
            raise PatchError("background importSettings anchor missing or ambiguous")
        text = text.replace(anchor, PREVIEW_FUNCTION + anchor, 1)
    old_handler = '''        case MESSAGE.IMPORT_SETTINGS: {
          const result = await importSettings(message.text);
          return { ok: true, ...result, dashboard: await dashboard() };
        }
'''
    new_handler = '''        case MESSAGE.PREVIEW_SETTINGS_IMPORT:
          return { ok: true, preview: await previewSettingsImport(message.text) };

        case MESSAGE.IMPORT_SETTINGS: {
          const result = await importSettings(message.text);
          return { ok: true, ...result, dashboard: await dashboard() };
        }
'''
    text = replace_once(text, old_handler, new_handler, "background preview handler")
    marker = "    MESSAGE.EXPORT_SUPPORT_BUNDLE,\n    MESSAGE.IMPORT_SETTINGS,"
    replacement = "    MESSAGE.EXPORT_SUPPORT_BUNDLE,\n    MESSAGE.PREVIEW_SETTINGS_IMPORT,\n    MESSAGE.IMPORT_SETTINGS,"
    if replacement not in text:
        count = text.count(marker)
        if count != 2:
            raise PatchError(f"background request allowlists: expected two Phase 59 markers, found {count}")
        text = text.replace(marker, replacement)
    if text.count("MESSAGE.PREVIEW_SETTINGS_IMPORT") < 3:
        raise PatchError("background preview message was not registered in handler and both allowlists")
    plan(rel, text)

    rel = "extension/sidebar/sidebar.js"
    text = read(rel)
    text = replace_once(
        text,
        "    MESSAGE.IMPORT_SETTINGS, MESSAGE.CREATE_SETTINGS_SNAPSHOT,\n",
        "    MESSAGE.PREVIEW_SETTINGS_IMPORT, MESSAGE.IMPORT_SETTINGS, MESSAGE.CREATE_SETTINGS_SNAPSHOT,\n",
        "sidebar mutating request set"
    )
    text = replace_once(text, OLD_IMPORT_UI, NEW_IMPORT_UI, "sidebar import preview/confirmation flow")
    plan(rel, text)

    ensure_created("tests/test_phase60_v0411_configuration_import_preview_confirmation.js", TEST_CONTENT)
    ensure_created("document/PHASE_60_V0_41_1_CONFIGURATION_IMPORT_PREVIEW_CONFIRMATION.md", DOC_CONTENT)

    rel = "CHANGELOG.md"
    text = read(rel)
    block = '''## [0.41.1] - 2026-08-07

### Added

- Read-only configuration import preview with explicit scope and library counts before any storage mutation.
- Explicit confirmation after preview for both full configuration bundles and legacy Automation-only files.

### Safety

- Selecting an invalid, unsupported or unintended configuration file no longer starts an import; the mutating request is sent only after successful preview and user confirmation.
- Recovery snapshots continue to be created immediately before the confirmed import.

### Compatibility

- Protocol remains 26 and Native Host remains 0.13.0.

'''
    if "## [0.41.1] - 2026-08-07" not in text:
        anchor = "## [0.41.0] - 2026-08-07"
        if text.count(anchor) != 1:
            raise PatchError("CHANGELOG.md: Phase 59 anchor missing or ambiguous")
        text = text.replace(anchor, block + anchor, 1)
    plan(rel, text)

    rel = "PROJECT_STATUS.md"
    text = read(rel)
    text = re.sub(r"- Current add-on version: \*\*[0-9.]+\*\*", "- Current add-on version: **0.41.1**", text, count=1)
    row = "| Configuration import preview | Read-only parse/summary and explicit confirmation before full or legacy configuration import mutates storage | **100%** | Completed in v0.41.1 |"
    if row not in text:
        anchor = "| Configuration scope return contract |"
        pos = text.find(anchor)
        if pos < 0:
            raise PatchError("PROJECT_STATUS.md: Phase 59 row missing")
        end = text.find("\n", pos)
        text = text[:end + 1] + row + "\n" + text[end + 1:]
    plan(rel, text)

    rel = "document/CURRENT_PROJECT_STATUS.md"
    text = read(rel)
    text = re.sub(r"\*\*Current baseline:\*\* Phase [0-9]+ v[0-9.]+", "**Current baseline:** Phase 60 v0.41.1", text, count=1)
    text = text.replace("Phase 04–59 contracts", "Phase 04–60 contracts")
    block = '''## Phase 60 v0.41.1 — Configuration import preview and confirmation

- Selecting a configuration file is now read-only until preview/validation succeeds and the user explicitly confirms the import.
- Preview distinguishes full all-configuration bundles from legacy Automation-only JSON and reports the libraries that will be replaced.
- The existing pre-import recovery snapshot remains the final safeguard immediately before mutation.

'''
    if "## Phase 60 v0.41.1" not in text:
        anchor = "## Phase 59 v0.41.0"
        if text.count(anchor) != 1:
            raise PatchError("CURRENT_PROJECT_STATUS.md: Phase 59 anchor missing or ambiguous")
        text = text.replace(anchor, block + anchor, 1)
    plan(rel, text)

    rel = "document/PROJECT_IMPLEMENTATION_PLAN.md"
    text = read(rel)
    text = re.sub(r"> \*\*Current implementation baseline:\*\* Phase [0-9]+ v[0-9.]+", "> **Current implementation baseline:** Phase 60 v0.41.1", text, count=1)
    if "## Phase 60 — Configuration import preview and confirmation" not in text:
        text = text.rstrip() + '''

## Phase 60 — Configuration import preview and confirmation

**Status:** Completed in v0.41.1.

- Parse and validate configuration files without mutation before import.
- Show full-vs-legacy scope and relevant library counts.
- Require explicit confirmation before the mutating import request while retaining the automatic pre-import recovery snapshot.
''' + "\n"
    plan(rel, text)

    rel = "README.md"
    text = read(rel)
    note = '''
### Preview before configuration import

Selecting a file in **Backup and transfer → Import all configuration** first performs a read-only validation and preview. The confirmation identifies whether the file is a full configuration bundle or legacy Automation-only configuration and summarizes the contained profile/preset/template libraries. Nothing is written until the user confirms; a recovery snapshot is then created immediately before the import.
'''
    if "### Preview before configuration import" not in text:
        marker = "### Full-scope import/restore activation"
        pos = text.find(marker)
        if pos < 0:
            raise PatchError("README.md: full-scope import/restore section missing")
        next_heading = text.find("\n## ", pos)
        text = text.rstrip() + note + "\n" if next_heading < 0 else text[:next_heading] + note + text[next_heading:]
    plan(rel, text)

    rel = "tools/test_firefox_addon.sh"
    text = read(rel)
    line = "node tests/test_phase60_v0411_configuration_import_preview_confirmation.js"
    if line not in text:
        anchor = "node tests/test_phase59_v0410_configuration_scope_return_contract.js"
        if text.count(anchor) != 1:
            raise PatchError("test runner: Phase 59 anchor missing or ambiguous")
        text = text.replace(anchor, anchor + "\n" + line, 1)
    text = text.replace(
        "PASS: FirefoxChatImprover Phase 04-59 v0.41.0 configuration scope return contract,",
        "PASS: FirefoxChatImprover Phase 04-60 v0.41.1 configuration import preview, configuration scope return contract,"
    )
    plan(rel, text)

def apply() -> list[str]:
    changed: list[str] = []
    for rel, target in planned.items():
        p = ROOT / rel
        current = p.read_text(encoding="utf-8") if p.is_file() else None
        if current == target:
            print(f"unchanged/check: {rel}")
            continue
        if p.is_file():
            backup_file(ROOT, rel, PATCH_NAME)
            print(f"patched: {rel}")
        else:
            p.parent.mkdir(parents=True, exist_ok=True)
            print(f"created: {rel}")
        p.write_text(target, encoding="utf-8")
        changed.append(rel)
    return changed

def run(cmd: list[str], label: str) -> None:
    print(f"CHECK: {label}")
    result = subprocess.run(cmd, cwd=ROOT)
    if result.returncode:
        raise PatchError(f"{label} failed with exit code {result.returncode}")

def validate(changed: list[str]) -> None:
    if not changed:
        print("CHECK: Phase 60 already applied; no commands run because no files changed.")
        return
    for rel in ["extension/shared/protocol.js", "extension/background/background.js", "extension/sidebar/sidebar.js"]:
        run(["node", "--check", rel], f"JavaScript syntax: {rel}")
    run(["bash", "-n", "tools/test_firefox_addon.sh"], "test runner shell syntax")
    focused = [
        "tests/test_phase19_settings_snapshots.js",
        "tests/test_phase29_v0290_component_profiles_custom_titles.js",
        "tests/test_phase43_v0394_configuration_session_io_separation.js",
        "tests/test_phase46_v0397_simplified_sidebar_feature_visibility.js",
        "tests/test_phase49_v0400_safe_profile_lifecycle.js",
        "tests/test_phase50_v0401_local_action_profile_save_draft_continuity.js",
        "tests/test_phase51_v0402_component_profile_editor_draft_continuity.js",
        "tests/test_phase52_v0403_non_destructive_profile_bundle_import.js",
        "tests/test_phase53_v0404_explicit_default_profile_controls.js",
        "tests/test_phase54_v0405_component_default_profile_controls.js",
        "tests/test_phase55_v0406_profile_action_clarity.js",
        "tests/test_phase56_v0407_working_session_profile_isolation.js",
        "tests/test_phase57_v0408_safe_configuration_restore.js",
        "tests/test_phase58_v0409_complete_configuration_backup.js",
        "tests/test_phase59_v0410_configuration_scope_return_contract.js",
        "tests/test_phase60_v0411_configuration_import_preview_confirmation.js",
    ]
    for test in focused:
        run(["node", test], Path(test).name)
    run(["python3", "tests/test_phase42_v0393_release_status_consistency.py"], "Phase 42 release-status consistency")
    if (ROOT / "tools/check_source_syntax.py").is_file():
        run(["bash", "tools/test_firefox_addon.sh"], "Phase 04-60 full regression")
    else:
        print("SKIP: full regression unavailable in reconstructed source; complete repo will run it.")

try:
    prepare()
    changed = apply()
    validate(changed)
    print(f"[PASS] Phase 60 v0.41.1 configuration import preview and confirmation (changed={len(changed)})")
except Exception as exc:
    print(f"[FAIL] {type(exc).__name__}: {exc}", file=sys.stderr)
    raise SystemExit(1)
