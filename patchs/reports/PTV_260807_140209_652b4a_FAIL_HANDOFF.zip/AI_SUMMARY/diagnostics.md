# Diagnostics

## 1. ERROR — log

- Location: `<not detected>`
- Message: [FAIL] PatchError: extension/manifest.json: expected v0.41.0 or v0.41.1, found 0.41.3
- Suggested next check: Likely stale patch anchor: use the CODE_CONTEXT ZIP to update old/anchor text against current source.
- Source: `patch_patchs_patch_firefox_chat_improver_phase60_v0_41_1_configuration_import_preview_confirmation_v3_2026_d9850744491a.raw.log`

```text
[FAIL] PatchError: extension/manifest.json: expected v0.41.0 or v0.41.1, found 0.41.3
```

## 2. ERROR — package

- Location: `<not detected>`
- Message: Stopping package after failed patch: patchs/patch_firefox_chat_improver_phase60_v0_41_1_configuration_import_preview_confirmation_v3_20260807_1245.zip::patch_firefox_chat_improver_phase60_v0_41_1_configuration_import_preview_confirmation_v3_20260807_1245.py
- Suggested next check: Inspect the first structured diagnostic and important log before the final package error.
- Source: `runner`

```text
Stopping package after failed patch: patchs/patch_firefox_chat_improver_phase60_v0_41_1_configuration_import_preview_confirmation_v3_20260807_1245.zip::patch_firefox_chat_improver_phase60_v0_41_1_configuration_import_preview_confirmation_v3_20260807_1245.py
```
