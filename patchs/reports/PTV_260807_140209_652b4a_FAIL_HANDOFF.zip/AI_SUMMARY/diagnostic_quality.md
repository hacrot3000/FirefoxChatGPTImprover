# Diagnostic quality

- tool_version: `5.16.0`
- structured_diagnostic_count: `2`
- root_cause_count: `1`
- secondary_suppressed: `1`
- raw_lines: `1`
- important_lines: `1`
- reduction_ratio: `0.0`
- raw_truncated: `False`
- secret_redactions: `0`
- status: `COMPLETE`
