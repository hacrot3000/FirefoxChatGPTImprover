# Root-cause candidates

Primary candidates: 1
Secondary/duplicate failures suppressed: 1

## ROOT-01 — `PTV-ANCHOR-001`

- Location: `<not detected>`
- Message: [FAIL] PatchError: extension/manifest.json: expected v0.41.0 or v0.41.1, found 0.41.3
- Suggested action: Likely stale patch anchor: use the CODE_CONTEXT ZIP to update old/anchor text against current source.
- Repeated occurrences: 1
