# NEXT AI ACTION

Primary diagnostic: `PTV-ANCHOR-001`
Failure delta: `SAME_FAILURE`
Action: Likely stale patch anchor: use the CODE_CONTEXT ZIP to update old/anchor text against current source.

## Files to inspect
1. Use the locations listed in `root_causes.md`.

## Constraints
- Return one ZIP patch using the standard manifest.
- Update the source baseline hashes when the corrected patch is generated against current code.
- Do not weaken exact-match or uniqueness checks merely to force the patch to pass.
- Do not modify unrelated files or project validation policy.
