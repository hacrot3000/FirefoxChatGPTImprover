# START HERE

Patch Tool: v5.16.0
Status: FAIL
Primary code: PTV-ANCHOR-001
Primary issue: [FAIL] PatchError: extension/manifest.json: expected v0.41.0 or v0.41.1, found 0.41.3
Location: <not detected>

Recommended action: Likely stale patch anchor: use the CODE_CONTEXT ZIP to update old/anchor text against current source.

Read `AI_SUMMARY/failure_delta.md`, `AI_SUMMARY/root_causes.md`, `AI_SUMMARY/diagnostic_quality.md`, `AI_SUMMARY/security_redaction.json`, `AI_SUMMARY/environment_fingerprint.md`, `AI_SUMMARY/multi_machine_context.md`, and `NEXT_AI_ACTION.md`, then inspect only the matching files under `CODE_CONTEXT/`. Do not require patch-history continuity across machines. Return one corrected Patch Tool ZIP with the same project key, relative paths, and strict uniqueness checks.
