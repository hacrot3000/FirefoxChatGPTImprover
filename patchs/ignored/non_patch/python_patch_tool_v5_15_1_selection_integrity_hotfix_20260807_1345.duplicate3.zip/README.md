# Python Patch Tool v5.15.1 — selection-integrity hotfix

This hotfix addresses a v5.15.0 zero-argument selection regression where a patch that was **not selected and not executed** could be moved to `patchs/ignored/duplicate_success/` after another selected package passed.

## Safety invariant

A package that was not executed must stay runnable. Only a package with execution evidence may be treated as completed. The guard snapshots the queue before the core runner, lets the original selector/runner operate normally, then checks whether an unexecuted queue file was newly moved to `ignored/duplicate_success`. If so, it restores that exact payload to `patchs/` and forces one duplicate-suppression bypass on the next explicit selection.

Pre-existing, positively-attested duplicates are left alone. User-deleted files, foreign-project files, non-patch archives and ordinary failures are not restored.

## Install

Run this updater **directly**, not through the affected Patch Tool runner:

```bash
python3 apply_patch_tool_v5_15_1_hotfix.py --project-root /home/duongtc/BleToNfc
```

Then continue normally:

```bash
cd /home/duongtc/BleToNfc
./tools/run_python_patches.sh
```

The installer backs up the existing public launcher and keeps its original core logic in `tools/run_python_patches_v5_15_0_core.sh`. All normal v5.15 functionality remains in the original core.

## Recovery for the reported incident

If present in `patchs/ignored/duplicate_success/`, the installer automatically restores:

`patch_nfc179_protected_read_consume_cleanup_boundary_v5_20260807_1320.zip`

The next selection bypasses duplicate suppression once so a stale/false local-history classification cannot hide the recovered package.
