#!/usr/bin/env python3
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
GUARD = HERE / "resources" / "python_patch_selection_integrity_guard.py"

FAKE = r'''#!/usr/bin/env python3
from pathlib import Path
import json, shutil, sys
root=Path.cwd(); p=root/'patchs'; reports=p/'reports'; reports.mkdir(parents=True,exist_ok=True)
patched=p/'patched'; ignored=p/'ignored'/'duplicate_success'; patched.mkdir(parents=True,exist_ok=True); ignored.mkdir(parents=True,exist_ok=True)
force='--force-repeat' in sys.argv
if (p/'patch_A.zip').exists():
    shutil.move(str(p/'patch_A.zip'), str(patched/'patch_A.zip'))
    if (p/'patch_B.zip').exists(): shutil.move(str(p/'patch_B.zip'), str(ignored/'patch_B.zip'))
    (reports/'LAST_RUN.md').write_text('PATCHES EXECUTED:\n  1. [PASS] patch_A.zip\nPATCHES SKIPPED / NOT EXECUTED:\n  1. [SKIPPED:DUPLICATE_SUCCESS] patch_B.zip\n')
elif (p/'patch_B.zip').exists() and force:
    shutil.move(str(p/'patch_B.zip'), str(patched/'patch_B.zip'))
    (reports/'LAST_RUN.md').write_text('PATCHES EXECUTED:\n  1. [PASS] patch_B.zip\nPATCHES SKIPPED / NOT EXECUTED:\n')
else:
    (reports/'LAST_RUN.md').write_text('PATCHES EXECUTED:\nPATCHES SKIPPED / NOT EXECUTED:\n')
sys.exit(0)
'''

def main():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); p=root/'patchs'; p.mkdir(); (p/'patch_A.zip').write_bytes(b'A'); (p/'patch_B.zip').write_bytes(b'B')
        core=root/'core.py'; core.write_text(FAKE); core.chmod(0o755)
        cmd=[sys.executable,str(GUARD),'--project-root',str(root),'--core',str(core),'--']
        r=subprocess.run(cmd); assert r.returncode==0
        assert (p/'patch_B.zip').is_file(), 'unexecuted B must be restored'
        assert not (p/'ignored'/'duplicate_success'/'patch_B.zip').exists()
        marker=p/'reports'/'.ptv5151_force_repeat_once'; assert marker.exists()
        r=subprocess.run(cmd); assert r.returncode==0
        assert (p/'patched'/'patch_B.zip').is_file(), 'recovered B must be runnable on next selection'
        assert not marker.exists()
    print('PASS: v5.15.1 selection-integrity guard restores unexecuted false duplicate and reruns it explicitly')

if __name__=='__main__': main()
