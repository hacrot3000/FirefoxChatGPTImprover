#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
import shutil
import sys
import time

MARKER = "PTV5151_SELECTION_INTEGRITY_GUARD"
CORE_NAME = "run_python_patches_v5_15_0_core.sh"
KNOWN_FALSE = "patch_nfc179_protected_read_consume_cleanup_boundary_v5_20260807_1320.zip"


def main() -> int:
    ap = argparse.ArgumentParser(description="Install Python Patch Tool v5.15.1 selection-integrity hotfix")
    ap.add_argument("--project-root", default=".")
    ap.add_argument("--recover-patch", action="append", default=[])
    ns = ap.parse_args()

    root = Path(ns.project_root).resolve()
    tools = root / "tools"
    lib = tools / "_patch_lib"
    launcher = tools / "run_python_patches.sh"
    if not launcher.is_file() or not lib.is_dir():
        raise SystemExit(f"Not a Patch Tool project root: {root}")

    resource = Path(__file__).resolve().parent / "resources" / "python_patch_selection_integrity_guard.py"
    if not resource.is_file():
        raise SystemExit("Hotfix resource missing: python_patch_selection_integrity_guard.py")

    current = launcher.read_text(encoding="utf-8", errors="replace")
    core = tools / CORE_NAME
    stamp = time.strftime("%Y%m%d_%H%M%S")
    backup_dir = lib / "backups" / f"v5_15_1_selection_integrity_{stamp}"
    backup_dir.mkdir(parents=True, exist_ok=True)

    if MARKER not in current:
        shutil.copy2(launcher, backup_dir / "run_python_patches.sh")
        if not core.exists():
            shutil.copy2(launcher, core)
            core.chmod(core.stat().st_mode | 0o111)
    elif not core.exists():
        raise SystemExit("Hotfix marker exists but core launcher backup is missing; refusing unsafe overwrite")

    guard = lib / "python_patch_selection_integrity_guard.py"
    shutil.copy2(resource, guard)
    guard.chmod(guard.stat().st_mode | 0o111)

    wrapper = f'''#!/usr/bin/env bash
# {MARKER}
# Python Patch Tool v5.15.1 selection-integrity hotfix.
set -euo pipefail
TOOLS_DIR="$(cd "$(dirname "${{BASH_SOURCE[0]}}")" && pwd)"
PROJECT_ROOT="$(cd "$TOOLS_DIR/.." && pwd)"
exec python3 "$TOOLS_DIR/_patch_lib/python_patch_selection_integrity_guard.py" \\
  --project-root "$PROJECT_ROOT" \\
  --core "$TOOLS_DIR/{CORE_NAME}" -- "$@"
'''
    launcher.write_text(wrapper, encoding="utf-8")
    launcher.chmod(launcher.stat().st_mode | 0o111)

    # Recover the exact package reported by this incident if present, plus any
    # explicitly requested package names. The runtime guard handles future cases.
    sys.path.insert(0, str(lib))
    import importlib.util
    spec = importlib.util.spec_from_file_location("ptv_guard", guard)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    targets = list(dict.fromkeys([KNOWN_FALSE, *ns.recover_patch]))
    recovered = []
    for name in targets:
        if mod.restore_known_false_duplicate(root, Path(name).name):
            recovered.append(Path(name).name)

    reports = root / "patchs" / "reports"
    if recovered:
        reports.mkdir(parents=True, exist_ok=True)
        (reports / mod.MARKER_NAME).write_text("\n".join(recovered) + "\n", encoding="utf-8")

    print("Python Patch Tool selection-integrity hotfix installed: v5.15.1")
    print(f"Project root : {root}")
    print(f"Public entry : {launcher}")
    print(f"Core backup  : {core}")
    print(f"Backup       : {backup_dir}")
    if recovered:
        print("Recovered unexecuted patch(es):")
        for name in recovered:
            print(f"  - patchs/{name}")
    else:
        print("No known false-duplicate package required one-time recovery.")
    print("Run normally: ./tools/run_python_patches.sh")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
